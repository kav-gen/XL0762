import React, { useState } from 'react';
import { 
  BookOpen, 
  FileText, 
  CheckCircle2, 
  Clock, 
  UploadCloud, 
  Download, 
  AlertCircle,
  FolderGit2,
  CalendarDays,
  ExternalLink
} from 'lucide-react';
import { LMSCourse, Assignment } from '../types/student';

interface LmsSectionProps {
  courses: LMSCourse[];
  assignments: Assignment[];
}

export const LmsSection: React.FC<LmsSectionProps> = ({ courses, assignments }) => {
  const [filter, setFilter] = useState<'all' | 'pending' | 'evaluated'>('all');
  const [submittingAssignmentId, setSubmittingAssignmentId] = useState<string | null>(null);
  const [submissionSuccess, setSubmissionSuccess] = useState<string | null>(null);

  const filteredAssignments = assignments.filter((asg) => {
    if (filter === 'pending') return asg.status === 'Pending';
    if (filter === 'evaluated') return asg.status === 'Evaluated';
    return true;
  });

  const handleFakeSubmit = (id: string) => {
    setSubmittingAssignmentId(null);
    setSubmissionSuccess(id);
    setTimeout(() => setSubmissionSuccess(null), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Top LMS Headline Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            Assignment Completion
          </div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono">
              94.0%
            </span>
            <span className="text-xs text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              On Schedule
            </span>
          </div>
          <div className="mt-2 text-xs text-slate-500">
            2 pending · 12 submitted this term
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            LMS Login Frequency
          </div>
          <div className="mt-1 flex items-baseline gap-2 font-mono">
            <span className="text-2xl sm:text-3xl font-extrabold text-blue-700">
              18
            </span>
            <span className="text-xs text-slate-500 font-medium">Days Streak</span>
          </div>
          <div className="mt-2 text-xs text-slate-600 font-medium">
            Daily active portal session
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            Courseware Materials
          </div>
          <div className="mt-1 flex items-baseline gap-2 font-mono">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              136
            </span>
            <span className="text-xs text-slate-500 font-medium">Files Synced</span>
          </div>
          <div className="mt-2 text-xs text-slate-600 font-medium">
            PDFs, PPTs, and Lab Manuals
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            Average Internal Assignment Score
          </div>
          <div className="mt-1 flex items-baseline gap-2 font-mono">
            <span className="text-2xl sm:text-3xl font-extrabold text-emerald-600">
              19.4
            </span>
            <span className="text-xs text-slate-500 font-medium">/ 20.0</span>
          </div>
          <div className="mt-2 text-xs text-emerald-700 font-semibold flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Top Percentile in Batch
          </div>
        </div>
      </div>

      {/* Active Courses Progress Grid */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Enrolled Courses & Digital Courseware (SEM-3)
            </h3>
            <p className="text-xs text-slate-500">
              Syllabus coverage and resource files provided by faculty.
            </p>
          </div>
          <span className="text-xs text-slate-600 font-medium">
            Autonomous Syllabus Revision 2024
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {courses.map((course) => (
            <div key={course.code} className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3 text-xs">
              <div className="flex items-start justify-between">
                <div>
                  <span className="font-mono font-bold text-blue-700">{course.code}</span>
                  <h4 className="font-bold text-slate-900 text-sm leading-snug mt-0.5">{course.name}</h4>
                  <div className="text-[11px] text-slate-500 font-medium mt-0.5">{course.faculty}</div>
                </div>
              </div>

              <div>
                <div className="flex justify-between font-semibold text-[11px] mb-1">
                  <span className="text-slate-600">Syllabus Progress</span>
                  <span className="font-mono text-slate-900">{course.progressPercentage}%</span>
                </div>
                <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-blue-600 h-1.5 rounded-full" style={{ width: `${course.progressPercentage}%` }} />
                </div>
              </div>

              <div className="flex items-center justify-between pt-1 border-t border-slate-200/60 text-[11px] text-slate-600">
                <span>{course.materialsCount} Lecture PDFs</span>
                <span className="font-medium">Accessed: {course.lastAccessed}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Assignments Ledger */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 bg-slate-50/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Coursework & Continuous Assessment Assignments
            </h3>
            <p className="text-xs text-slate-500">
              Submit lab reports, case studies, and code archives before deadlines.
            </p>
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-200/60 rounded-lg">
            <button
              onClick={() => setFilter('all')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                filter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setFilter('pending')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                filter === 'pending' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              Pending (3)
            </button>
            <button
              onClick={() => setFilter('evaluated')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                filter === 'evaluated' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              Evaluated
            </button>
          </div>
        </div>

        {submissionSuccess && (
          <div className="p-3 bg-emerald-50 border-b border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            Assignment submitted successfully! Encrypted timestamp stored.
          </div>
        )}

        <div className="divide-y divide-slate-100 text-xs">
          {filteredAssignments.map((asg) => (
            <div key={asg.id} className="p-4 hover:bg-slate-50/70 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-blue-700">{asg.courseCode}</span>
                  <span className="text-slate-400">·</span>
                  <span className="font-bold text-slate-900 text-sm">{asg.title}</span>
                </div>
                <div className="text-slate-600 font-medium">
                  {asg.courseName} · Max Marks: <span className="font-mono font-bold text-slate-800">{asg.points}</span>
                </div>

                {asg.feedback && (
                  <div className="p-2 bg-blue-50/60 rounded border border-blue-100 text-[11px] text-blue-900 mt-1">
                    <span className="font-semibold">Faculty Feedback:</span> {asg.feedback}
                  </div>
                )}
              </div>

              <div className="flex items-center gap-3 shrink-0 self-start md:self-auto">
                <div className="text-right hidden sm:block">
                  <div className="text-[11px] text-slate-500">
                    {asg.status === 'Evaluated' ? 'Submitted On' : 'Due Date'}
                  </div>
                  <div className="font-mono font-semibold text-slate-800">
                    {asg.status === 'Evaluated' ? asg.submissionDate : asg.dueDate}
                  </div>
                </div>

                {asg.status === 'Evaluated' ? (
                  <div className="text-right">
                    <span className="inline-block px-2.5 py-1 bg-emerald-50 border border-emerald-200 rounded-md font-mono font-bold text-emerald-700">
                      Score: {asg.score} / {asg.points}
                    </span>
                  </div>
                ) : (
                  <button
                    onClick={() => setSubmittingAssignmentId(asg.id)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg shadow-xs transition-colors whitespace-nowrap"
                  >
                    <UploadCloud className="w-3.5 h-3.5" />
                    Submit Solution
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Submission Modal */}
      {submittingAssignmentId && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full border border-slate-200 p-5 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h4 className="font-bold text-slate-900 text-sm">Upload Assignment Solution</h4>
              <button onClick={() => setSubmittingAssignmentId(null)} className="text-slate-400 font-bold">✕</button>
            </div>
            <p className="text-slate-600">
              Attach your source code archive (.zip) or laboratory report (.pdf).
            </p>
            <div className="border-2 border-dashed border-slate-300 rounded-lg p-5 text-center text-slate-500 hover:border-blue-500 cursor-pointer">
              <UploadCloud className="w-8 h-8 text-blue-500 mx-auto mb-1" />
              <div className="font-semibold text-slate-700">Drag & drop files or click to browse</div>
              <div className="text-[11px] text-slate-400 mt-0.5">PDF, ZIP, IPYNB accepted (max 25MB)</div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button onClick={() => setSubmittingAssignmentId(null)} className="px-3 py-1.5 rounded border border-slate-200">
                Cancel
              </button>
              <button 
                onClick={() => handleFakeSubmit(submittingAssignmentId)}
                className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded"
              >
                Confirm & Submit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
