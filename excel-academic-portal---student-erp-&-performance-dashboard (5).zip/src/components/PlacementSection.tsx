import React, { useState } from 'react';
import { 
  Briefcase, 
  Code2, 
  BrainCircuit, 
  CheckCircle2, 
  ExternalLink, 
  Building2, 
  TrendingUp, 
  UserCheck, 
  Sparkles,
  Trophy,
  Play
} from 'lucide-react';
import { PlacementMetric } from '../types/student';

interface PlacementSectionProps {
  metrics: PlacementMetric;
}

export const PlacementSection: React.FC<PlacementSectionProps> = ({ metrics }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'companies' | 'interviews' | 'coding'>('overview');
  const [practiceModal, setPracticeModal] = useState<boolean>(false);

  return (
    <div className="space-y-6">
      {/* Top PAT Headline Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            Placement Readiness Index
          </div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-extrabold text-blue-700 font-mono">
              87.2%
            </span>
            <span className="text-xs text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              Tier-1 Track
            </span>
          </div>
          <div className="mt-2 text-xs text-slate-600 font-medium">
            Eligible for Dream Offers (8 - 14 LPA)
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            Coding Assessment Benchmark
          </div>
          <div className="mt-1 flex items-baseline gap-2 font-mono">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              {metrics.codingScore}
            </span>
            <span className="text-xs text-slate-500 font-medium">/ 100</span>
          </div>
          <div className="mt-2 text-xs text-emerald-700 font-semibold flex items-center gap-1">
            <Trophy className="w-3.5 h-3.5" />
            Rank 4 in CSBS Department
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            Aptitude & Verbal Score
          </div>
          <div className="mt-1 flex items-baseline gap-2 font-mono">
            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              {metrics.aptitudeScore}
            </span>
            <span className="text-xs text-slate-500 font-medium">/ 100</span>
          </div>
          <div className="mt-2 text-xs text-slate-600 font-medium">
            Quant: 86 · Logical: 88 · Verbal: 84
          </div>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
            PAT Mock Interview Rating
          </div>
          <div className="mt-1 flex items-baseline gap-2 font-mono">
            <span className="text-2xl sm:text-3xl font-extrabold text-emerald-600">
              {metrics.mockInterviewScore}
            </span>
            <span className="text-xs text-slate-500 font-medium">/ 5.0</span>
          </div>
          <div className="mt-2 text-xs text-emerald-700 font-semibold flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Cleared Phase 1 Panel
          </div>
        </div>
      </div>

      {/* Sub-navigation Controls */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
            activeTab === 'overview'
              ? 'bg-slate-900 text-white'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Assessment Breakdown
        </button>
        <button
          onClick={() => setActiveTab('companies')}
          className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
            activeTab === 'companies'
              ? 'bg-slate-900 text-white'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Company Eligibility (5 Eligible)
        </button>
        <button
          onClick={() => setActiveTab('interviews')}
          className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
            activeTab === 'interviews'
              ? 'bg-slate-900 text-white'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          PAT Mock Interview Feedback
        </button>
        <button
          onClick={() => setActiveTab('coding')}
          className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
            activeTab === 'coding'
              ? 'bg-slate-900 text-white'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Coding Portfolios & LeetCode
        </button>
      </div>

      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Aptitude & Technical Scores Card */}
          <div className="p-5 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <BrainCircuit className="w-4 h-4 text-blue-600" />
              PAT Internal Assessment Breakdown
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <div className="flex justify-between font-medium mb-1">
                  <span className="text-slate-700">Quantitative Aptitude</span>
                  <span className="font-mono font-bold text-slate-900">86%</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div className="bg-blue-600 h-2 rounded-full" style={{ width: '86%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between font-medium mb-1">
                  <span className="text-slate-700">Logical Reasoning & Puzzles</span>
                  <span className="font-mono font-bold text-slate-900">88%</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div className="bg-blue-600 h-2 rounded-full" style={{ width: '88%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between font-medium mb-1">
                  <span className="text-slate-700">Verbal & Business Communication</span>
                  <span className="font-mono font-bold text-slate-900">84%</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div className="bg-blue-600 h-2 rounded-full" style={{ width: '84%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between font-medium mb-1">
                  <span className="text-slate-700">Core Computer Science & OOP Concepts</span>
                  <span className="font-mono font-bold text-slate-900">92%</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div className="bg-emerald-600 h-2 rounded-full" style={{ width: '92%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between font-medium mb-1">
                  <span className="text-slate-700">Competitive Programming (Data Structures)</span>
                  <span className="font-mono font-bold text-slate-900">88%</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div className="bg-emerald-600 h-2 rounded-full" style={{ width: '88%' }} />
                </div>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => setPracticeModal(true)}
                className="w-full py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 font-semibold rounded-lg border border-blue-200 transition-colors text-xs flex items-center justify-center gap-1.5"
              >
                <Play className="w-3.5 h-3.5" />
                Launch Timed Aptitude Practice Sprint
              </button>
            </div>
          </div>

          {/* Placement Training Roadmap */}
          <div className="p-5 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-slate-700" />
              Autonomous PAT Training Milestones
            </h3>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex items-start gap-3">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold text-slate-900">Phase 1: Foundation Aptitude & C++ OOP</div>
                  <div className="text-slate-600">Completed in SEM-2 with Distinction score.</div>
                </div>
              </div>

              <div className="p-3 bg-blue-50/50 rounded-lg border border-blue-200 flex items-start gap-3">
                <Sparkles className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold text-blue-900">Phase 2: Advanced DSA & System Architecture (Active)</div>
                  <div className="text-blue-800">Targeting LeetCode Medium/Hard graphs, DP, and SQL optimization.</div>
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex items-start gap-3">
                <div className="w-4 h-4 rounded-full border border-slate-300 shrink-0 mt-0.5 flex items-center justify-center text-[10px] text-slate-400">
                  3
                </div>
                <div>
                  <div className="font-bold text-slate-700">Phase 3: Company Mock Drives & HR Clinic</div>
                  <div className="text-slate-500">Scheduled for SEM-4 (Pre-Final Year Drive).</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'companies' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 bg-slate-50/60 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Target Company Eligibility Matcher
              </h3>
              <p className="text-xs text-slate-500">
                Automated matching against your 8.72 CGPA, 0 Arrears, and PAT Coding Benchmark.
              </p>
            </div>
            <span className="text-xs font-semibold px-2.5 py-1 bg-white rounded-md border border-slate-200 text-emerald-700">
              5 of 5 Criteria Met
            </span>
          </div>

          <div className="divide-y divide-slate-100 text-xs">
            {metrics.targetCompanies.map((c) => (
              <div key={c.company} className="p-4 hover:bg-slate-50/70 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 text-sm">{c.company}</span>
                    <span className="text-[11px] font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                      {c.tier}
                    </span>
                  </div>
                  <div className="text-slate-600 font-medium">{c.role}</div>
                  <div className="text-slate-500 font-mono">Package Band: <span className="font-bold text-slate-800">{c.packageLpa}</span></div>
                </div>

                <div className="flex items-center gap-3">
                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    Eligible for Shortlisting
                  </span>
                  <button className="px-3 py-1 text-slate-700 hover:bg-slate-100 rounded-lg border border-slate-200 font-semibold transition-colors">
                    View Syllabus
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'interviews' && (
        <div className="space-y-4">
          {metrics.interviewRemarks.map((remark, idx) => (
            <div key={idx} className="p-5 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-2 text-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 border-b border-slate-100 pb-2">
                <div className="font-bold text-slate-900 text-sm">{remark.interviewer}</div>
                <div className="text-slate-500 font-mono">{remark.date}</div>
              </div>
              <div className="inline-block font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                {remark.verdict}
              </div>
              <p className="text-slate-700 leading-relaxed pt-1">
                "{remark.notes}"
              </p>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'coding' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {metrics.codingProfiles.map((p) => (
            <div key={p.platform} className="p-5 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-2 text-xs">
              <div className="font-bold text-slate-900 text-sm flex items-center justify-between">
                <span>{p.platform}</span>
                <Code2 className="w-4 h-4 text-slate-500" />
              </div>
              <div className="font-mono text-emerald-700 font-semibold">{p.rating}</div>
              <div className="text-slate-600">
                Problems Solved: <span className="font-mono font-bold text-slate-900">{p.solved}</span>
              </div>
              <div className="pt-2">
                <span className="text-[11px] text-blue-600 font-semibold hover:underline cursor-pointer flex items-center gap-1">
                  View Verified Profile <ExternalLink className="w-3 h-3" />
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Practice Modal Mock */}
      {practiceModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full border border-slate-200 p-5 space-y-3 text-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h4 className="font-bold text-slate-900 text-sm">PAT 30-Min Rapid Aptitude Test</h4>
              <button onClick={() => setPracticeModal(false)} className="text-slate-400 font-bold">✕</button>
            </div>
            <p className="text-slate-600">
              Module: 15 Questions on Number Theory, Permutations & Data Interpretation. Timer starts on launch.
            </p>
            <div className="p-3 bg-slate-50 rounded border border-slate-200 font-mono text-[11px] text-slate-700">
              Target Pass Benchmark: &gt; 80% (12/15 Correct)
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button onClick={() => setPracticeModal(false)} className="px-3 py-1.5 rounded border border-slate-200">
                Close
              </button>
              <button 
                onClick={() => {
                  alert('Launching PAT Assessment Terminal (Timed 30:00)... Good luck!');
                  setPracticeModal(false);
                }}
                className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded"
              >
                Start Assessment
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
