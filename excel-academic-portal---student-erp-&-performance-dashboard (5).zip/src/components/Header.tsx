import React, { useState, useRef, useEffect } from 'react';
import { 
  Building2, 
  User, 
  CreditCard, 
  Printer, 
  ShieldCheck, 
  ChevronDown,
  Sparkles,
  GraduationCap,
  Users,
  Check,
  ChevronRight
} from 'lucide-react';
import { StudentProfile } from '../types/student';
import { GlobalSearch } from './GlobalSearch';

export type PortalRole = 'student' | 'staff' | 'hod';

interface HeaderProps {
  currentRole: PortalRole;
  onRoleChange: (role: PortalRole) => void;
  student: StudentProfile;
  activeTab: string;
  onTabChange: (tab: string) => void;
  onOpenProfile: () => void;
  onOpenStudentID: () => void;
  onPrintTranscript: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentRole,
  onRoleChange,
  student,
  activeTab,
  onTabChange,
  onOpenProfile,
  onOpenStudentID,
  onPrintTranscript,
}) => {
  const [isRoleDropdownOpen, setIsRoleDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsRoleDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // All 6 core tabs for Student Dashboard as strictly requested:
  // Overview, Academics, Attendance, Placement, LMS, Interventions for MENMITHA S
  // Plus Skills and Feedback preserved
  const studentTabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'academic', label: 'Academics' },
    { id: 'attendance', label: 'Attendance (91.8%)' },
    { id: 'placement', label: 'Placement & PAT' },
    { id: 'lms', label: 'LMS & Assignments' },
    { id: 'segmentation', label: 'Interventions for MENMITHA S' },
    { id: 'skills', label: 'Skills & Honors' },
    { id: 'feedback', label: 'Feedback' },
  ];

  const roleOptions: { id: PortalRole; title: string; subtitle: string; icon: React.ReactNode; badge: string }[] = [
    {
      id: 'student',
      title: 'Student View',
      subtitle: 'MENMITHA S · B.Tech CSBS (Autonomous)',
      icon: <GraduationCap className="w-4 h-4 text-blue-700" />,
      badge: '6 Tabs & Zoro Copilot'
    },
    {
      id: 'staff',
      title: 'Staff View',
      subtitle: 'Dr. K. Vigneshwaran · Class Advisor',
      icon: <Users className="w-4 h-4 text-emerald-700" />,
      badge: '60 Assigned Students & AI Risk Queue'
    },
    {
      id: 'hod',
      title: 'HOD View',
      subtitle: 'Dr. S. Rajendran · Head of Department',
      icon: <Building2 className="w-4 h-4 text-indigo-700" />,
      badge: '500 Dept Students & Workload Analytics'
    }
  ];

  const currentRoleConfig = roleOptions.find(r => r.id === currentRole) || roleOptions[0];

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs no-print">
      {/* Top Institutional Identity Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 border-b border-slate-100 gap-2 sm:gap-4">
          
          {/* Institution Crest & Name */}
          <div className="flex items-center gap-2.5 shrink-0">
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-lg overflow-hidden border border-slate-200 bg-white shrink-0 shadow-2xs flex items-center justify-center">
              <img 
                src={student.collegeLogoUrl} 
                alt="College Crest" 
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xs sm:text-base font-bold text-slate-900 tracking-tight leading-tight truncate max-w-[140px] sm:max-w-none">
                  {student.college}
                </h1>
                <span className="hidden lg:inline-flex items-center gap-1 text-[11px] font-semibold text-blue-800 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                  <ShieldCheck className="w-3 h-3 text-blue-600" />
                  NAAC A+ Autonomous
                </span>
              </div>
              <p className="text-[11px] sm:text-xs text-slate-500 font-medium hidden sm:block">
                Unified Academic ERP · Regulation 2024 · B.Tech CSBS
              </p>
            </div>
          </div>

          {/* Working Global Search Bar */}
          <div className="flex-1 max-w-xs md:max-w-sm lg:max-w-md mx-1 sm:mx-2 hidden md:block">
            <GlobalSearch onNavigateTab={onTabChange} />
          </div>

          {/* RIGHT: Top Bar Role Switcher Dropdown & Actions */}
          <div className="flex items-center gap-2 shrink-0">
            
            {/* Top Bar Role Switcher: Dropdown to toggle between Student View, Staff View, and HOD View */}
            <div className="relative" ref={dropdownRef}>
              <button
                type="button"
                onClick={() => setIsRoleDropdownOpen(!isRoleDropdownOpen)}
                className="flex items-center gap-2 px-3 py-1.5 rounded-xl border border-blue-600 bg-blue-700 text-white hover:bg-blue-800 transition-all shadow-xs cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500"
                aria-expanded={isRoleDropdownOpen}
                aria-haspopup="true"
              >
                <div className="w-5 h-5 rounded-full bg-white/20 flex items-center justify-center shrink-0">
                  {currentRole === 'student' && <GraduationCap className="w-3.5 h-3.5 text-white" />}
                  {currentRole === 'staff' && <Users className="w-3.5 h-3.5 text-white" />}
                  {currentRole === 'hod' && <Building2 className="w-3.5 h-3.5 text-white" />}
                </div>
                <div className="text-left">
                  <div className="text-xs font-bold leading-tight flex items-center gap-1">
                    <span>{currentRoleConfig.title}</span>
                    <ChevronDown className={`w-3.5 h-3.5 text-blue-200 transition-transform ${isRoleDropdownOpen ? 'rotate-180' : ''}`} />
                  </div>
                  <div className="text-[10px] text-blue-100 hidden sm:block font-medium">
                    {currentRole === 'student' ? 'MENMITHA S' : currentRole === 'staff' ? '60 Mentees' : '500 Dept'}
                  </div>
                </div>
              </button>

              {/* Dropdown Menu */}
              {isRoleDropdownOpen && (
                <div className="absolute right-0 mt-2 w-72 sm:w-80 bg-white rounded-2xl shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in zoom-in-95">
                  <div className="px-3 py-2 border-b border-slate-100 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                    Select Portal View / Role
                  </div>

                  <div className="p-1 space-y-1">
                    {roleOptions.map((role) => {
                      const isSelected = currentRole === role.id;
                      return (
                        <button
                          key={role.id}
                          type="button"
                          onClick={() => {
                            onRoleChange(role.id);
                            setIsRoleDropdownOpen(false);
                          }}
                          className={`w-full text-left p-2.5 rounded-xl transition-all flex items-start justify-between gap-2.5 ${
                            isSelected
                              ? 'bg-blue-50 text-blue-900 border border-blue-200 shadow-2xs'
                              : 'hover:bg-slate-50 text-slate-800'
                          }`}
                        >
                          <div className="flex items-start gap-2.5">
                            <div className={`p-2 rounded-lg mt-0.5 shrink-0 ${
                              isSelected ? 'bg-blue-700 text-white' : 'bg-slate-100 text-slate-600'
                            }`}>
                              {role.icon}
                            </div>
                            <div>
                              <div className="text-xs font-bold flex items-center gap-1.5">
                                {role.title}
                                {isSelected && (
                                  <span className="text-[10px] bg-blue-700 text-white font-bold px-1.5 py-0.2 rounded-full">
                                    Active
                                  </span>
                                )}
                              </div>
                              <p className="text-[11px] text-slate-600 mt-0.5 leading-snug">
                                {role.subtitle}
                              </p>
                              <span className="inline-block mt-1 text-[10px] text-blue-700 font-medium bg-blue-50/80 px-1.5 py-0.5 rounded">
                                {role.badge}
                              </span>
                            </div>
                          </div>
                          {isSelected && (
                            <Check className="w-4 h-4 text-blue-700 shrink-0 mt-1" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Student ID Card Quick Trigger */}
            <button
              onClick={onOpenStudentID}
              title="View & Print Official College Student ID Card"
              className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition-colors whitespace-nowrap"
            >
              <CreditCard className="w-3.5 h-3.5 text-blue-600" />
              <span>ID Card</span>
            </button>

            {/* Print Official Summary Button */}
            <button
              onClick={onPrintTranscript}
              title="Print official academic student record"
              className="hidden lg:inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors whitespace-nowrap"
            >
              <Printer className="w-3.5 h-3.5 text-slate-600" />
              <span>Transcript</span>
            </button>

            {/* Profile Drawer Trigger */}
            <button
              onClick={onOpenProfile}
              className="flex items-center gap-2 pl-1.5 pr-2.5 py-1 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50/80 transition-colors text-left"
              title="Click to view Camu SIS Profile & Records"
            >
              <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full overflow-hidden border border-slate-200 bg-slate-100 shrink-0">
                <img 
                  src={student.avatarUrl} 
                  alt={student.name} 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="hidden sm:block">
                <div className="text-xs font-bold text-slate-900 leading-tight">
                  {student.firstName}
                </div>
                <div className="text-[10px] text-slate-500 font-mono">
                  {student.rollNo}
                </div>
              </div>
            </button>
          </div>
        </div>

        {/* Primary Functional Tabs: Rendered when in Student View */}
        {currentRole === 'student' && (
          <nav className="flex items-center gap-1 overflow-x-auto py-2 scrollbar-none" aria-label="Student Portal Navigation">
            {studentTabs.map((tab) => {
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => onTabChange(tab.id)}
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                    isActive
                      ? 'bg-blue-700 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </nav>
        )}

        {/* When in Staff or HOD view: Render quick contextual breadcrumb/indicator */}
        {currentRole === 'staff' && (
          <div className="py-2 flex items-center justify-between text-xs text-slate-600 border-t border-slate-50">
            <div className="flex items-center gap-2 font-semibold">
              <span className="text-blue-700 font-bold">Staff View Active:</span>
              <span>Dr. K. Vigneshwaran (Class Advisor) · 60 Assigned Students (Sections A & B)</span>
            </div>
            <span className="hidden sm:inline-block text-[11px] font-mono bg-rose-50 text-rose-700 px-2 py-0.5 rounded font-bold">
              AI Early Warning Queue: 12 High / 18 Medium Risk
            </span>
          </div>
        )}

        {currentRole === 'hod' && (
          <div className="py-2 flex items-center justify-between text-xs text-slate-600 border-t border-slate-50">
            <div className="flex items-center gap-2 font-semibold">
              <span className="text-blue-700 font-bold">HOD View Active:</span>
              <span>Dr. S. Rajendran (Head of Department) · 500 Students (Sections A, B, C, D)</span>
            </div>
            <span className="hidden sm:inline-block text-[11px] font-mono bg-blue-50 text-blue-700 px-2 py-0.5 rounded font-bold">
              24 Full-Time Faculty Workload Analytics
            </span>
          </div>
        )}
      </div>
    </header>
  );
};
