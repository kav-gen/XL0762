import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, 
  X, 
  BookOpen, 
  User, 
  FileText, 
  Clock, 
  Briefcase, 
  Award, 
  Target, 
  ChevronRight,
  ArrowRight
} from 'lucide-react';
import { 
  academicRecords, 
  attendanceData, 
  lmsCourses, 
  assignmentsList, 
  placementMetrics, 
  skillsInventory, 
  studentSegments 
} from '../data/studentData';

interface SearchResultItem {
  id: string;
  title: string;
  subtitle: string;
  category: 'Course' | 'Faculty' | 'Assignment' | 'Placement' | 'Attendance' | 'Skill' | 'Segment';
  targetTab: string;
  metadata?: string;
}

interface GlobalSearchProps {
  onNavigateTab: (tab: string) => void;
}

export const GlobalSearch: React.FC<GlobalSearchProps> = ({ onNavigateTab }) => {
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  // Close dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Collect all searchable records
  const allItems: SearchResultItem[] = [
    // Courses from academic records
    ...academicRecords[2].subjects.map(s => ({
      id: `course-${s.code}`,
      title: `${s.code}: ${s.name}`,
      subtitle: `Faculty: ${s.faculty} · Credits: ${s.credits} · Predicted: ${s.predictedGrade}`,
      category: 'Course' as const,
      targetTab: 'academic',
      metadata: 'CIA 1 & 2'
    })),
    // Faculty members
    {
      id: 'faculty-saravanan',
      title: 'Prof. K. Saravanan',
      subtitle: 'Class Advisor & Proctor · Courses: DAA, Python, Algorithms Lab',
      category: 'Faculty' as const,
      targetTab: 'feedback',
      metadata: 'Cabin 304'
    },
    {
      id: 'faculty-kavitha',
      title: 'Dr. P. Kavitha',
      subtitle: 'HOD & Professor · Course: Database Management Systems & NoSQL',
      category: 'Faculty' as const,
      targetTab: 'feedback',
      metadata: 'Dept Head'
    },
    {
      id: 'faculty-murugesan',
      title: 'Dr. R. Murugesan',
      subtitle: 'Course Faculty · Discrete Mathematics & Combinatorics',
      category: 'Faculty' as const,
      targetTab: 'academic',
      metadata: 'Maths Dept'
    },
    {
      id: 'faculty-jayanthi',
      title: 'Dr. M. Jayanthi',
      subtitle: 'Course Faculty · Operating Systems & System Calls',
      category: 'Faculty' as const,
      targetTab: 'academic',
      metadata: 'Tech Block'
    },
    // Assignments
    ...assignmentsList.map(a => ({
      id: `asg-${a.id}`,
      title: a.title,
      subtitle: `${a.courseCode} · Due: ${a.dueDate} · Status: ${a.status} (${a.points} pts)`,
      category: 'Assignment' as const,
      targetTab: 'lms',
      metadata: a.status
    })),
    // Placement targets
    ...placementMetrics.targetCompanies.map(c => ({
      id: `company-${c.company}`,
      title: `${c.company} (${c.tier})`,
      subtitle: `Role: ${c.role} · Package: ${c.packageLpa} · Status: Eligible`,
      category: 'Placement' as const,
      targetTab: 'placement',
      metadata: 'Recruitment Drive'
    })),
    // Attendance items
    ...attendanceData.subjectWise.map(a => ({
      id: `att-${a.code}`,
      title: `${a.code} Attendance: ${a.percentage}%`,
      subtitle: `${a.name} · Safe margin: +${a.canBunkClasses} classes buffer`,
      category: 'Attendance' as const,
      targetTab: 'attendance',
      metadata: a.status
    })),
    // Skills & certifications
    ...skillsInventory.map(s => ({
      id: `skill-${s.name}`,
      title: `${s.name} (${s.proficiency}%)`,
      subtitle: `${s.category} Competency · Verified by ${s.verifiedBy}`,
      category: 'Skill' as const,
      targetTab: 'skills',
      metadata: 'Benchmarked'
    })),
    // Segments
    ...studentSegments.map(seg => ({
      id: `seg-${seg.id}`,
      title: seg.name,
      subtitle: `Criteria: ${seg.criteria} · ${seg.studentCountInCollege} Students`,
      category: 'Segment' as const,
      targetTab: 'segmentation',
      metadata: seg.currentStudentBelongs ? 'Your Cohort' : 'Intervention'
    }))
  ];

  const filteredResults = query.trim() === '' 
    ? [] 
    : allItems.filter(item => 
        item.title.toLowerCase().includes(query.toLowerCase()) ||
        item.subtitle.toLowerCase().includes(query.toLowerCase()) ||
        item.category.toLowerCase().includes(query.toLowerCase())
      ).slice(0, 8);

  const handleSelectResult = (item: SearchResultItem) => {
    onNavigateTab(item.targetTab);
    setQuery('');
    setIsOpen(false);
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Course': return <BookOpen className="w-3.5 h-3.5 text-blue-600" />;
      case 'Faculty': return <User className="w-3.5 h-3.5 text-emerald-600" />;
      case 'Assignment': return <FileText className="w-3.5 h-3.5 text-amber-600" />;
      case 'Placement': return <Briefcase className="w-3.5 h-3.5 text-purple-600" />;
      case 'Attendance': return <Clock className="w-3.5 h-3.5 text-cyan-600" />;
      case 'Skill': return <Award className="w-3.5 h-3.5 text-indigo-600" />;
      case 'Segment': return <Target className="w-3.5 h-3.5 text-rose-600" />;
      default: return <Search className="w-3.5 h-3.5 text-slate-400" />;
    }
  };

  return (
    <div ref={searchRef} className="relative w-full max-w-xs sm:max-w-md">
      {/* Search Input Bar */}
      <div className="relative">
        <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
        <input
          type="text"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          placeholder="Search subjects, faculty, marks, assignments..."
          className="w-full pl-8 pr-8 py-1.5 bg-slate-100 hover:bg-slate-100/80 focus:bg-white text-xs border border-transparent focus:border-blue-400 rounded-lg text-slate-800 placeholder-slate-400 transition-all focus:outline-hidden focus:ring-2 focus:ring-blue-100"
        />
        {query && (
          <button
            onClick={() => setQuery('')}
            className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Dropdown Results */}
      {isOpen && query.trim() !== '' && (
        <div className="absolute left-0 right-0 mt-1.5 bg-white rounded-xl shadow-xl border border-slate-200 z-50 overflow-hidden divide-y divide-slate-100 animate-in fade-in zoom-in-95 duration-100">
          <div className="px-3 py-1.5 bg-slate-50 text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
            <span>Matching Academic Records ({filteredResults.length})</span>
            <span>Click to navigate</span>
          </div>

          {filteredResults.length > 0 ? (
            <div className="max-h-72 overflow-y-auto divide-y divide-slate-100">
              {filteredResults.map((result) => (
                <button
                  key={result.id}
                  onClick={() => handleSelectResult(result)}
                  className="w-full text-left p-2.5 hover:bg-blue-50/60 transition-colors flex items-start gap-2.5 group"
                >
                  <div className="p-1.5 rounded-md bg-slate-100 group-hover:bg-white transition-colors shrink-0 mt-0.5">
                    {getCategoryIcon(result.category)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-slate-900 text-xs truncate">
                        {result.title}
                      </span>
                      <span className="text-[10px] font-semibold text-slate-500 bg-slate-100 px-1.5 py-0.2 rounded shrink-0">
                        {result.category}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 truncate mt-0.5">
                      {result.subtitle}
                    </p>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-blue-600 shrink-0 self-center opacity-0 group-hover:opacity-100 transition-opacity" />
                </button>
              ))}
            </div>
          ) : (
            <div className="p-4 text-center text-xs text-slate-500">
              No matching records found for "{query}". Try searching by course code (e.g., CB301, DAA), faculty name, or company.
            </div>
          )}
        </div>
      )}
    </div>
  );
};
