import React, { useState } from 'react';
import { 
  X, 
  FileCode2, 
  Copy, 
  Check, 
  Download, 
  ExternalLink,
  Code2,
  FolderTree
} from 'lucide-react';

interface SourceCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SourceCodeModal: React.FC<SourceCodeModalProps> = ({ isOpen, onClose }) => {
  const [activeFile, setActiveFile] = useState<string>('student.ts');
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  const fileContents: Record<string, { title: string; path: string; code: string }> = {
    'student.ts': {
      title: 'TypeScript Domain Types',
      path: 'src/types/student.ts',
      code: `// Domain Types for Academic ERP Portal
export interface StudentProfile {
  id: string;
  name: string;
  title: string;
  firstName: string;
  lastName: string;
  status: 'Active' | 'Inactive' | 'On Leave';
  admissionNo: string;
  admissionYear: string;
  rollNo: string;
  degree: string;
  department: string;
  courseName: string;
  college: string;
  semester: string;
  section: string;
  academicYear: string;
  curriculumPlan: string;
  academicStanding: string;
  dob: string;
  age: number;
  gender: 'Female' | 'Male' | 'Other';
  fatherName: string;
  motherName: string;
  address: string;
  city: string;
  state: string;
  email: string;
  phone: string;
  avatarUrl: string;
}

export interface SubjectGrade {
  code: string;
  name: string;
  credits: number;
  type: 'Theory' | 'Practical' | 'Integrated';
  faculty: string;
  cia1: number;
  cia2: number;
  modelExam: number;
  internalTotal: number;
  predictedGrade: 'O' | 'A+' | 'A' | 'B+' | 'B' | 'RA';
  status: 'Passed' | 'In Progress' | 'Arrear';
}

export interface StudentSegment {
  id: string;
  name: string;
  criteria: string;
  description: string;
  colorTheme: string;
  studentCountInCollege: number;
  interventionPlan: string[];
  recommendedAction: string;
  currentStudentBelongs: boolean;
}`
    },
    'AttendanceSection.tsx': {
      title: 'Attendance & Bunk Simulator',
      path: 'src/components/AttendanceSection.tsx',
      code: `// Mathematical Threshold & Bunk Margin Simulator
export const AttendanceSection: React.FC<AttendanceSectionProps> = ({ data }) => {
  const [selectedSubjectCode, setSelectedSubjectCode] = useState<string>('CB301');
  const [hypotheticalMissedClasses, setHypotheticalMissedClasses] = useState<number>(2);
  const [hypotheticalAttendedClasses, setHypotheticalAttendedClasses] = useState<number>(4);

  const selectedSubject = data.subjectWise.find(s => s.code === selectedSubjectCode);

  // Projected ratio calculation
  const simTotalConducted = selectedSubject.conducted + hypotheticalMissedClasses + hypotheticalAttendedClasses;
  const simTotalAttended = selectedSubject.attended + selectedSubject.odApproved + hypotheticalAttendedClasses;
  const simPercentage = ((simTotalAttended / simTotalConducted) * 100).toFixed(1);

  return (
    <div className="space-y-6">
      {/* 75% Autonomous Threshold Compliance Checks */}
      <div className="metric-strip">
        <span className="font-mono">{data.overallPercentage}%</span>
        {data.overallPercentage >= 75.0 ? <EligibleBadge /> : <ShortageAlert />}
      </div>
    </div>
  );
};`
    },
    'SegmentationSection.tsx': {
      title: 'Student Segmentation Matrix (Bonus)',
      path: 'src/components/SegmentationSection.tsx',
      code: `// Multidimensional Student Segmentation & Targeted Intervention
export const SegmentationSection: React.FC<SegmentationSectionProps> = ({ segments, currentStudent }) => {
  const [selectedSegmentId, setSelectedSegmentId] = useState<string>(segments[0].id);

  // Cohort Analysis:
  // 1. High Academic · High Placement (Exemplars / Super-Dream)
  // 2. High Academic · Low Placement (Bridge Cohort / Coding Sprints)
  // 3. Moderate Academic · High Placement (Theory Remedial / Backlog Prevention)
  // 4. Attendance Risk (< 78% / Hall Ticket Intervention)
  return (
    <div className="grid grid-cols-2 gap-4">
      {segments.map((seg) => (
        <SegmentCard key={seg.id} segment={seg} onSelect={setSelectedSegmentId} />
      ))}
    </div>
  );
};`
    },
    'App.tsx': {
      title: 'Main Application Shell',
      path: 'src/App.tsx',
      code: `import React, { useState } from 'react';
import { Header } from './components/Header';
import { AcademicSection } from './components/AcademicSection';
import { AttendanceSection } from './components/AttendanceSection';
import { PlacementSection } from './components/PlacementSection';
import { LMSSection } from './components/LmsSection';
import { SkillsSection } from './components/SkillsSection';
import { SegmentationSection } from './components/SegmentationSection';
import { FeedbackSection } from './components/FeedbackSection';
import { ProfileDrawer } from './components/ProfileDrawer';

export default function App() {
  const [activeTab, setActiveTab] = useState('overview');
  // Full white professional human-crafted ERP architecture
  return <Layout activeTab={activeTab} onTabChange={setActiveTab} />;
}`
    }
  };

  const currentFile = fileContents[activeFile] || fileContents['student.ts'];

  const handleCopyCode = () => {
    navigator.clipboard.writeText(currentFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([currentFile.code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = activeFile;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl border border-slate-200 flex flex-col max-h-[85vh] animate-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-blue-100 border border-blue-200 flex items-center justify-center text-blue-700">
              <FileCode2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-slate-900">
                Student ERP Source Code & Template Export
              </h3>
              <p className="text-xs text-slate-500 font-mono">
                Clean, human-made TypeScript + React + Tailwind architecture
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyCode}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied!' : 'Copy Code'}</span>
            </button>
            <button
              onClick={handleDownload}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download File</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg border border-slate-200 ml-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* File Switcher Bar */}
        <div className="flex items-center gap-2 px-5 py-2.5 bg-slate-100 border-b border-slate-200 overflow-x-auto text-xs">
          <span className="font-semibold text-slate-500 uppercase text-[11px] mr-1">Modules:</span>
          {Object.keys(fileContents).map((fileKey) => (
            <button
              key={fileKey}
              onClick={() => setActiveFile(fileKey)}
              className={`px-3 py-1 rounded-md font-mono transition-colors whitespace-nowrap ${
                activeFile === fileKey
                  ? 'bg-white text-blue-700 font-bold shadow-2xs border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {fileKey}
            </button>
          ))}
        </div>

        {/* Code View Area */}
        <div className="flex-1 overflow-y-auto p-5 bg-slate-950 text-slate-100 font-mono text-xs leading-relaxed">
          <div className="text-[11px] text-slate-500 pb-3 border-b border-slate-800 mb-3 flex items-center justify-between">
            <span>// File: {currentFile.path}</span>
            <span>UTF-8 · TypeScript</span>
          </div>
          <pre className="overflow-x-auto whitespace-pre font-mono text-slate-200">
            {currentFile.code}
          </pre>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 text-center text-xs text-slate-500">
          Ready to deploy into any Vite / Next.js / Create-React-App project without modifications.
        </div>
      </div>
    </div>
  );
};
