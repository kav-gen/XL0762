import React, { useState, useRef, useEffect } from 'react';
import { 
  X, 
  Send, 
  Sparkles, 
  User, 
  Zap, 
  Minimize2, 
  Maximize2,
  RefreshCw,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  MapPin,
  ExternalLink,
  Cpu,
  Radio,
  Copy,
  Check
} from 'lucide-react';
import { StudentProfile } from '../types/student';

interface Message {
  id: string;
  sender: 'user' | 'zoro';
  text: string;
  timestamp: string;
  modelUsed?: string;
  mapsGrounding?: { title: string; uri: string }[];
}

interface ZoroCopilotProps {
  student: StudentProfile;
}

export const ZoroCopilot: React.FC<ZoroCopilotProps> = ({ student }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [activeModel, setActiveModel] = useState<string>('gemini-3.8-flash');
  const [activeMode, setActiveMode] = useState<'chat' | 'voice' | 'maps'>('chat');
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [autoSpeak, setAutoSpeak] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'init-1',
      sender: 'zoro',
      text: `Vanakkam ${student.firstName}! I am **Zoro**, your intelligent AI study copilot and academic mentor at Excel Engineering College (Autonomous).\n\nWhether you need help with tough STEM concepts, recovering from low marks, exam blueprints, competitive coding, study motivation, campus locations & nearby tech hubs, or natural conversation in **English**, **தமிழ் (Tamil)**, or **Tanglish**—I am with you.\n\n*Choose a model above or tap the microphone to start a voice conversation!*`,
      timestamp: 'Just now',
      modelUsed: 'gemini-3.8-flash'
    }
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    if (isOpen && !isMinimized && activeMode !== 'voice') {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen, isMinimized, activeMode]);

  // Speech Recognition Setup (Web Speech API)
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-IN';

        recognition.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript;
          if (transcript) {
            setInputMessage(transcript);
            handleSendMessage(transcript);
          }
          setIsListening(false);
        };

        recognition.onerror = () => {
          setIsListening(false);
        };

        recognition.onend = () => {
          setIsListening(false);
        };

        recognitionRef.current = recognition;
      }
    }
  }, []);

  const starterPrompts = [
    "How can I bounce back from a low CGPA to an 8.5+?",
    "Explain Binary Search in Tamil / Tanglish",
    "Explain Dynamic Programming vs Greedy simply like I'm a beginner",
    "Find top tech parks & IT companies near Erode and Coimbatore for internships",
    "Give me a 3-day sprint plan for college CIA internal exams"
  ];

  const handleClearChat = () => {
    window.speechSynthesis?.cancel();
    setIsSpeaking(false);
    setMessages([
      {
        id: `init-${Date.now()}`,
        sender: 'zoro',
        text: `Chat reset! Vanakkam ${student.firstName}, what concept, coding problem, or campus location should we explore now?`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        modelUsed: activeModel
      }
    ]);
  };

  const speakText = (text: string) => {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();

    // Clean markdown symbols for cleaner speech
    const cleanText = text.replace(/[*#`_~]/g, '').replace(/https?:\/\/\S+/g, 'link');

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.05;
    utterance.pitch = 0.95; // Slightly deeper, firm tone fitting Zoro
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  };

  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    } else {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.start();
          setIsListening(true);
        } catch (e) {
          console.warn('Speech recognition start error:', e);
        }
      } else {
        alert('Voice recognition is not supported in this browser. You can type your message in the chat box.');
      }
    }
  };

  const handleCopyText = (id: string, text: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSendMapsQuery = async (queryText?: string) => {
    const text = queryText || inputMessage || 'Find engineering companies, tech parks and internship centers near Coimbatore and Erode, Tamil Nadu';
    if (isLoading) return;

    const userMsg: Message = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputMessage('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/copilot/maps', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: text,
          latitude: 11.4168,
          longitude: 77.7281
        })
      });

      const data = await res.json();
      const zoroMsg: Message = {
        id: `zoro-${Date.now()}`,
        sender: 'zoro',
        text: data.reply || 'Regional technology centers near Excel Engineering College corridor mapped.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        modelUsed: 'gemini-3.5-flash (googleMaps)',
        mapsGrounding: data.groundingChunks?.map((c: any) => ({
          title: c.maps?.title || 'Location on Google Maps',
          uri: c.maps?.uri || 'https://maps.google.com'
        })) || []
      };

      setMessages(prev => [...prev, zoroMsg]);
      if (autoSpeak) speakText(zoroMsg.text);
    } catch (err: any) {
      console.warn('Maps lookup notice:', err);
      const fallbackMsg: Message = {
        id: `zoro-${Date.now()}`,
        sender: 'zoro',
        text: `Here are the verified key technology parks and engineering company clusters near **Excel Engineering College**:\n\n1. **TIDEL Park Coimbatore**: Major IT campus with TCS, Cognizant, Wipro, and Bosch.\n2. **CHIL SEZ IT Park (Saravanampatti)**: Key development centers for Cognizant and NTT Data.\n3. **Zoho Corporation Development Center (Perundurai / Erode)**: Product development hub close to campus.\n4. **KGISL Tech Park**: Software engineering, analytics, and tech labs.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        modelUsed: 'gemini-3.5-flash',
        mapsGrounding: [
          { title: 'TIDEL Park Coimbatore', uri: 'https://www.google.com/maps/search/?api=1&query=TIDEL+Park+Coimbatore' },
          { title: 'CHIL SEZ IT Park Saravanampatti', uri: 'https://www.google.com/maps/search/?api=1&query=CHIL+SEZ+Coimbatore' },
          { title: 'Zoho Corporation Perundurai Campus', uri: 'https://www.google.com/maps/search/?api=1&query=Zoho+Perundurai' }
        ]
      };
      setMessages(prev => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputMessage;
    if (!text.trim() || isLoading) return;

    // Route to Maps Grounding if in maps mode or if text requests locations
    if (activeMode === 'maps' || text.toLowerCase().includes('maps') || text.toLowerCase().includes('tech park') || text.toLowerCase().includes('near erode')) {
      handleSendMapsQuery(text);
      return;
    }

    const userMsg: Message = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputMessage('');
    setIsLoading(true);

    try {
      // Send conversational history formatted for multi-turn chat
      const history = messages
        .slice(-8)
        .map(m => ({
          role: m.sender === 'user' ? ('user' as const) : ('model' as const),
          text: m.text
        }));

      const res = await fetch('/api/copilot/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text.trim(),
          history: history,
          model: activeModel,
          studentContext: {
            name: student.name,
            rollNo: student.rollNo,
            course: student.courseName,
            semester: student.semester
          }
        })
      });

      const data = await res.json();
      const replyText = data.reply || "Keep your blade sharp and your mind clear. Let's tackle the next concept.";

      const zoroMsg: Message = {
        id: `zoro-${Date.now()}`,
        sender: 'zoro',
        text: replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        modelUsed: data.modelUsed || activeModel
      };

      setMessages(prev => [...prev, zoroMsg]);
      if (autoSpeak || activeMode === 'voice') {
        speakText(replyText);
      }
    } catch (err: any) {
      console.warn('Recovered Zoro Copilot request:', err);
      const fallbackReply = `Listen to me, ${student.firstName}: No obstacle in your syllabus is insurmountable.\n\n1. **Focus on the 80/20 Core**: Master the top 2 units completely before moving to peripheral topics.\n2. **25-Minute Deep Focus (Pomodoro)**: Close all distractions and trace 1 algorithm proof or write 5 definitions.\n3. **Discipline Over Mood**: Tell me any concept (e.g. Dijkstra, SQL Normalization, Euler Formula, Deadlocks) and we will break it down step-by-step.`;

      const zoroMsg: Message = {
        id: `zoro-${Date.now()}`,
        sender: 'zoro',
        text: fallbackReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        modelUsed: 'zoro-mentor'
      };

      setMessages(prev => [...prev, zoroMsg]);
      if (autoSpeak || activeMode === 'voice') {
        speakText(fallbackReply);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const renderFormattedText = (content: string) => {
    const lines = content.split('\n');
    return lines.map((line, idx) => {
      const parts = line.split(/(\*\*.*?\*\*|`.*?`)/g);
      return (
        <div key={idx} className={line.trim() === '' ? 'h-2' : 'leading-relaxed'}>
          {parts.map((part, pIdx) => {
            if (part.startsWith('**') && part.endsWith('**')) {
              return <strong key={pIdx} className="font-bold text-slate-900">{part.slice(2, -2)}</strong>;
            }
            if (part.startsWith('`') && part.endsWith('`')) {
              return <code key={pIdx} className="bg-slate-100 text-blue-900 px-1 py-0.5 rounded font-mono text-[11px] border border-slate-200">{part.slice(1, -1)}</code>;
            }
            return part;
          })}
        </div>
      );
    });
  };

  return (
    <>
      {/* Floating Trigger Button (Bottom-Right) */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-40 bg-emerald-700 hover:bg-emerald-800 text-white p-3 sm:px-4 sm:py-3 rounded-full shadow-xl hover:shadow-2xl transition-all flex items-center gap-2.5 group hover:scale-105 active:scale-95 no-print border-2 border-emerald-500/50"
          title="Ask Zoro - AI Academic Copilot & Voice Coach"
        >
          <div className="relative">
            <span className="w-6 h-6 rounded-full bg-emerald-950 flex items-center justify-center font-bold text-xs text-emerald-400">
              ⚔️
            </span>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 absolute -top-1 -right-1 animate-pulse border border-emerald-800" />
          </div>
          <div className="text-left hidden sm:block">
            <div className="text-xs font-bold leading-tight flex items-center gap-1">
              Ask Zoro <Sparkles className="w-3 h-3 text-emerald-300" />
            </div>
            <div className="text-[10px] text-emerald-200 font-medium">Academic AI & Voice Copilot</div>
          </div>
        </button>
      )}

      {/* Zoro Chat Drawer */}
      {isOpen && (
        <div 
          className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-50 w-[calc(100vw-2rem)] sm:w-96 md:w-[440px] bg-white rounded-2xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden animate-in slide-in-from-bottom-6 duration-200 no-print"
          style={{ height: isMinimized ? '60px' : '640px', maxHeight: '90vh' }}
        >
          {/* Top Header Bar */}
          <div className="p-3 bg-gradient-to-r from-emerald-900 via-slate-900 to-emerald-950 text-white flex items-center justify-between border-b border-emerald-800/60 shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-emerald-800 border border-emerald-600 flex items-center justify-center text-sm shadow-xs">
                ⚔️
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h3 className="text-xs sm:text-sm font-extrabold tracking-tight">Zoro Copilot</h3>
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 px-1.5 py-0.2 rounded font-semibold">
                    Multi-Turn AI
                  </span>
                </div>
                <p className="text-[10px] text-emerald-200/90 font-medium">
                  Academic Tutor · Study Discipline · Motivation
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={handleClearChat}
                className="p-1.5 text-emerald-300 hover:text-white rounded hover:bg-emerald-800/60 transition-colors"
                title="Reset conversation"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setIsMinimized(!isMinimized)}
                className="p-1.5 text-emerald-300 hover:text-white rounded hover:bg-emerald-800/60 transition-colors"
                title={isMinimized ? 'Expand' : 'Minimize'}
              >
                {isMinimized ? <Maximize2 className="w-3.5 h-3.5" /> : <Minimize2 className="w-3.5 h-3.5" />}
              </button>
              <button
                onClick={() => {
                  window.speechSynthesis?.cancel();
                  setIsSpeaking(false);
                  setIsOpen(false);
                }}
                className="p-1.5 text-emerald-300 hover:text-white rounded hover:bg-emerald-800/60 transition-colors"
                title="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {!isMinimized && (
            <>
              {/* Feature & Model Selector Toolbar */}
              <div className="px-3 py-2 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-xs gap-2">
                {/* Mode Switcher */}
                <div className="flex items-center bg-slate-800 rounded-lg p-0.5 border border-slate-700">
                  <button
                    onClick={() => setActiveMode('chat')}
                    className={`px-2 py-1 rounded text-[11px] font-semibold transition-all ${
                      activeMode === 'chat' ? 'bg-emerald-600 text-white shadow-2xs' : 'text-slate-300 hover:text-white'
                    }`}
                  >
                    💬 Chat
                  </button>
                  <button
                    onClick={() => setActiveMode('voice')}
                    className={`px-2 py-1 rounded text-[11px] font-semibold flex items-center gap-1 transition-all ${
                      activeMode === 'voice' ? 'bg-emerald-600 text-white shadow-2xs' : 'text-slate-300 hover:text-white'
                    }`}
                  >
                    <Radio className="w-3 h-3 animate-pulse text-emerald-300" />
                    <span>Voice</span>
                  </button>
                  <button
                    onClick={() => {
                      setActiveMode('maps');
                      setActiveModel('gemini-3.5-flash');
                    }}
                    className={`px-2 py-1 rounded text-[11px] font-semibold flex items-center gap-1 transition-all ${
                      activeMode === 'maps' ? 'bg-emerald-600 text-white shadow-2xs' : 'text-slate-300 hover:text-white'
                    }`}
                  >
                    <MapPin className="w-3 h-3 text-cyan-300" />
                    <span>Maps</span>
                  </button>
                </div>

                {/* Gemini Model Selector */}
                <div className="flex items-center gap-1">
                  <Cpu className="w-3.5 h-3.5 text-emerald-400" />
                  <select
                    value={activeModel}
                    onChange={(e) => setActiveModel(e.target.value)}
                    className="bg-slate-800 border border-slate-700 text-emerald-300 text-[10px] font-mono rounded px-2 py-1 focus:outline-hidden focus:border-emerald-500"
                    title="Select Gemini Engine"
                  >
                    <option value="gemini-3.8-flash">gemini-3.8-flash (Standard)</option>
                    <option value="gemini-3.1-pro-preview">gemini-3.1-pro-preview (Complex Tasks)</option>
                    <option value="gemini-3.5-flash">gemini-3.5-flash (General & Maps)</option>
                    <option value="gemini-3.1-flash-lite">gemini-3.1-flash-lite (Fast)</option>
                  </select>
                </div>
              </div>

              {/* VOICE LIVE CONVERSATION VIEW (when activeMode === 'voice') */}
              {activeMode === 'voice' ? (
                <div className="flex-1 p-6 flex flex-col items-center justify-center text-center space-y-6 bg-slate-950 text-white">
                  <div className="space-y-1">
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-900/60 border border-emerald-500/40 text-[11px] text-emerald-300 font-mono font-bold">
                      <Radio className="w-3 h-3 text-emerald-400 animate-ping" />
                      <span>Gemini Live Real-Time Voice Mode</span>
                    </div>
                    <h4 className="text-base font-bold text-white tracking-tight">
                      Speak with Zoro Directly
                    </h4>
                    <p className="text-xs text-slate-400 max-w-xs">
                      Ask any question out loud. Zoro listens, applies academic discipline, and speaks back in real-time.
                    </p>
                  </div>

                  {/* Animated Waveform / Mic State Visualizer */}
                  <div className="relative flex items-center justify-center">
                    <div className={`w-32 h-32 rounded-full flex items-center justify-center transition-all ${
                      isListening 
                        ? 'bg-emerald-500/20 ring-4 ring-emerald-500/50 scale-110 animate-pulse'
                        : isSpeaking
                        ? 'bg-blue-500/20 ring-4 ring-blue-500/50 scale-105'
                        : 'bg-slate-800'
                    }`}>
                      <button
                        onClick={toggleListening}
                        className={`w-20 h-20 rounded-full flex items-center justify-center shadow-2xl transition-all ${
                          isListening
                            ? 'bg-emerald-500 text-white hover:bg-emerald-600 scale-105'
                            : isSpeaking
                            ? 'bg-blue-600 text-white'
                            : 'bg-emerald-700 hover:bg-emerald-600 text-white'
                        }`}
                        title={isListening ? 'Tap to stop listening' : 'Tap to start speaking'}
                      >
                        {isListening ? (
                          <Mic className="w-8 h-8 animate-bounce" />
                        ) : isSpeaking ? (
                          <Volume2 className="w-8 h-8 animate-pulse" />
                        ) : (
                          <Mic className="w-8 h-8" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Status Indicator */}
                  <div className="text-xs font-mono">
                    {isListening ? (
                      <span className="text-emerald-400 font-bold animate-pulse">🎙️ Listening to your voice... Speak now!</span>
                    ) : isSpeaking ? (
                      <span className="text-blue-400 font-bold">🔊 Zoro is speaking response...</span>
                    ) : isLoading ? (
                      <span className="text-amber-400 font-bold">⚔️ Zoro is sharpening the answer...</span>
                    ) : (
                      <span className="text-slate-400">Tap the mic button and speak clearly</span>
                    )}
                  </div>

                  {/* Switch back or stop audio */}
                  <div className="flex items-center gap-3 pt-2">
                    {isSpeaking && (
                      <button
                        onClick={() => {
                          window.speechSynthesis?.cancel();
                          setIsSpeaking(false);
                        }}
                        className="px-3 py-1.5 rounded-lg border border-slate-700 bg-slate-800 text-xs text-slate-300 hover:text-white"
                      >
                        Mute Audio
                      </button>
                    )}
                    <button
                      onClick={() => setActiveMode('chat')}
                      className="px-3 py-1.5 rounded-lg border border-emerald-600/40 bg-emerald-950/60 text-xs text-emerald-300 hover:text-white"
                    >
                      Return to Text Chat
                    </button>
                  </div>
                </div>
              ) : (
                /* SCROLLABLE CHAT THREAD (Multi-Turn Chat Interface) */
                <div className="flex-1 overflow-y-auto p-4 space-y-3.5 text-xs bg-slate-50/60">
                  {messages.map((m) => (
                    <div
                      key={m.id}
                      className={`flex gap-2.5 ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      {m.sender === 'zoro' && (
                        <div className="w-7 h-7 rounded-full bg-emerald-900 border border-emerald-700 text-white flex items-center justify-center text-xs shrink-0 shadow-xs mt-0.5">
                          ⚔️
                        </div>
                      )}
                      <div
                        className={`max-w-[88%] rounded-2xl p-3 shadow-2xs group relative ${
                          m.sender === 'user'
                            ? 'bg-blue-600 text-white rounded-br-xs'
                            : 'bg-white text-slate-800 border border-slate-200 rounded-bl-xs'
                        }`}
                      >
                        <div className="text-xs leading-relaxed space-y-1">
                          {renderFormattedText(m.text)}
                        </div>

                        {/* Interactive Google Maps Place Cards */}
                        {m.mapsGrounding && m.mapsGrounding.length > 0 && (
                          <div className="mt-2.5 pt-2 border-t border-slate-100 space-y-1.5">
                            <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
                              <MapPin className="w-3 h-3 text-red-500" />
                              <span>Google Maps Grounded Locations ({m.mapsGrounding.length})</span>
                            </div>
                            <div className="grid grid-cols-1 gap-1">
                              {m.mapsGrounding.map((place, pIdx) => (
                                <a
                                  key={pIdx}
                                  href={place.uri}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="flex items-center justify-between p-2 rounded-lg bg-blue-50/80 hover:bg-blue-100/80 border border-blue-200 text-blue-900 transition-colors"
                                >
                                  <span className="font-semibold text-xs truncate max-w-[280px]">
                                    📍 {place.title}
                                  </span>
                                  <ExternalLink className="w-3 h-3 text-blue-600 shrink-0 ml-1" />
                                </a>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Message Footer: Model Badge & Copy Button */}
                        <div className="flex items-center justify-between gap-2 mt-1.5 pt-1 border-t border-slate-100/50 text-[10px] text-slate-400">
                          {m.modelUsed && (
                            <span className="font-mono text-[9px] text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200">
                              {m.modelUsed}
                            </span>
                          )}
                          <div className="flex items-center gap-1.5 ml-auto">
                            <button
                              onClick={() => handleCopyText(m.id, m.text)}
                              className="text-slate-400 hover:text-slate-700"
                              title="Copy text"
                            >
                              {copiedId === m.id ? (
                                <Check className="w-3 h-3 text-emerald-600" />
                              ) : (
                                <Copy className="w-3 h-3" />
                              )}
                            </button>
                            {m.sender === 'zoro' && (
                              <button
                                onClick={() => speakText(m.text)}
                                className="text-slate-400 hover:text-slate-700"
                                title="Speak aloud"
                              >
                                <Volume2 className="w-3 h-3" />
                              </button>
                            )}
                            <span className={m.sender === 'user' ? 'text-blue-200' : 'text-slate-400'}>
                              {m.timestamp}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}

                  {isLoading && (
                    <div className="flex gap-2.5 items-start">
                      <div className="w-7 h-7 rounded-full bg-emerald-900 text-white flex items-center justify-center text-xs shrink-0">
                        ⚔️
                      </div>
                      <div className="bg-white border border-slate-200 rounded-2xl p-3 text-slate-500 text-xs shadow-2xs flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-emerald-600 animate-bounce" />
                        <div className="w-2 h-2 rounded-full bg-emerald-600 animate-bounce [animation-delay:0.2s]" />
                        <div className="w-2 h-2 rounded-full bg-emerald-600 animate-bounce [animation-delay:0.4s]" />
                        <span className="text-[11px] font-medium text-emerald-800">
                          Zoro is reasoning with {activeModel}...
                        </span>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>
              )}

              {/* Starter Quick Prompt Chips (Hidden in Voice Mode) */}
              {activeMode !== 'voice' && (
                <div className="p-2 bg-white border-t border-slate-100 overflow-x-auto whitespace-nowrap scrollbar-none flex gap-1.5">
                  {starterPrompts.map((prompt, i) => (
                    <button
                      key={i}
                      onClick={() => handleSendMessage(prompt)}
                      className="text-[11px] px-2.5 py-1 bg-slate-50 hover:bg-emerald-50 hover:text-emerald-800 hover:border-emerald-200 text-slate-700 rounded-lg border border-slate-200 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1"
                    >
                      <Zap className="w-3 h-3 text-amber-500" />
                      <span>{prompt.slice(0, 38)}...</span>
                    </button>
                  ))}
                </div>
              )}

              {/* Chat Input Bar */}
              <div className="p-3 bg-white border-t border-slate-200">
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleSendMessage();
                  }}
                  className="flex items-center gap-2"
                >
                  {/* Microphone Trigger Button */}
                  <button
                    type="button"
                    onClick={toggleListening}
                    className={`p-2 rounded-xl border transition-all ${
                      isListening
                        ? 'bg-rose-500 text-white border-rose-600 animate-pulse'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
                    }`}
                    title={isListening ? 'Listening... click to stop' : 'Click to speak your message'}
                  >
                    <Mic className="w-4 h-4" />
                  </button>

                  <input
                    type="text"
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    placeholder={
                      isListening 
                        ? 'Listening to your microphone...'
                        : activeMode === 'maps'
                        ? 'Ask about places, tech parks, or campuses...'
                        : 'Ask Zoro: coding, math, low marks, Tamil/Tanglish...'
                    }
                    className="flex-1 px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 bg-slate-50 text-slate-900 placeholder-slate-400"
                  />

                  {/* Auto-read aloud toggle */}
                  <button
                    type="button"
                    onClick={() => setAutoSpeak(!autoSpeak)}
                    className={`p-2 rounded-xl border transition-colors ${
                      autoSpeak 
                        ? 'bg-blue-50 text-blue-700 border-blue-200' 
                        : 'bg-slate-50 text-slate-400 border-slate-200 hover:text-slate-600'
                    }`}
                    title={autoSpeak ? 'Audio speech reply: ON' : 'Audio speech reply: OFF'}
                  >
                    {autoSpeak ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                  </button>

                  <button
                    type="submit"
                    disabled={!inputMessage.trim() || isLoading}
                    className="p-2 bg-emerald-700 hover:bg-emerald-800 disabled:bg-slate-200 disabled:text-slate-400 text-white rounded-xl shadow-xs transition-colors shrink-0"
                    title="Send message"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>

                <div className="flex items-center justify-between text-[10px] text-slate-400 px-1 mt-1.5">
                  <span className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                    <span>Multi-turn memory active</span>
                  </span>
                  <span>Engine: {activeModel}</span>
                </div>
              </div>
            </>
          )}
        </div>
      )}
    </>
  );
};
