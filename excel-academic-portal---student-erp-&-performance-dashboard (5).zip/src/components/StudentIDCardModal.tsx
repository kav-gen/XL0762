import React, { useState } from 'react';
import { 
  X, 
  Printer, 
  RotateCw, 
  ShieldCheck, 
  QrCode, 
  Download, 
  CheckCircle2, 
  UserCheck,
  CreditCard
} from 'lucide-react';
import { StudentProfile } from '../types/student';

interface StudentIDCardModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: StudentProfile;
}

export const StudentIDCardModal: React.FC<StudentIDCardModalProps> = ({
  isOpen,
  onClose,
  student
}) => {
  const [isFlipped, setIsFlipped] = useState(false);

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full border border-slate-200 p-6 space-y-5 animate-in zoom-in-95 duration-150">
        {/* Modal Top Actions */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-3 no-print">
          <div className="flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-blue-600" />
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Official Student Identity Card</h3>
              <p className="text-[11px] text-slate-500 font-mono">Academic Year 2025-2029 · Autonomous</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsFlipped(!isFlipped)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
            >
              <RotateCw className="w-3.5 h-3.5 text-slate-600" />
              <span>{isFlipped ? 'Show Front' : 'Flip to Back'}</span>
            </button>
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Print ID</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg border border-slate-200 ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* 3D-Like Physical Student ID Card Container */}
        <div className="flex justify-center py-2">
          {!isFlipped ? (
            /* FRONT OF ID CARD */
            <div className="w-80 sm:w-88 bg-gradient-to-b from-blue-900 via-blue-950 to-slate-950 text-white rounded-2xl shadow-xl overflow-hidden border border-blue-800/60 p-4 space-y-3 relative">
              {/* College Header */}
              <div className="flex items-center gap-3 border-b border-blue-800/80 pb-2.5">
                <div className="w-10 h-10 rounded-full bg-white p-0.5 shrink-0 overflow-hidden shadow-xs">
                  <img
                    src={student.collegeLogoUrl}
                    alt="College Logo"
                    className="w-full h-full object-contain"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div>
                  <h4 className="text-xs font-extrabold uppercase tracking-tight text-white leading-tight">
                    {student.college}
                  </h4>
                  <p className="text-[9px] text-blue-200 uppercase tracking-widest font-semibold">
                    Autonomous · Affiliated to Anna University
                  </p>
                </div>
              </div>

              {/* Student Photo & Vital Meta */}
              <div className="flex items-start gap-3.5 pt-1">
                <div className="w-24 h-32 rounded-lg overflow-hidden border-2 border-white/80 shadow-md bg-white shrink-0">
                  <img
                    src={student.avatarUrl}
                    alt={student.name}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div className="space-y-1 text-left flex-1 min-w-0">
                  <div className="text-[10px] text-blue-300 font-semibold uppercase tracking-wider">
                    Student ID Card
                  </div>
                  <h3 className="text-sm font-extrabold text-white tracking-tight truncate">
                    {student.name}
                  </h3>
                  <div className="text-[11px] text-blue-100 font-mono font-semibold">
                    Roll: <span className="text-white">{student.rollNo}</span>
                  </div>
                  <div className="text-[10px] text-blue-200 font-mono">
                    Reg: {student.admissionNo}
                  </div>
                  <div className="text-[10px] text-blue-100 font-medium leading-tight pt-0.5">
                    {student.courseName}
                  </div>
                  <div className="text-[10px] text-emerald-400 font-bold pt-1">
                    Valid: 2025 - 2029
                  </div>
                </div>
              </div>

              {/* Barcode & Signature Strip */}
              <div className="border-t border-blue-800/80 pt-2 flex items-center justify-between text-[10px] text-blue-200">
                <div className="space-y-0.5">
                  <div className="font-mono text-[9px] tracking-widest">||| |||| || ||||| |||||||</div>
                  <div className="text-[8px] text-blue-300 font-mono">{student.rollNo}-CSBS-AUTONOMOUS</div>
                </div>
                <div className="text-right">
                  <div className="text-[9px] font-serif italic text-blue-200 font-bold underline decoration-blue-400">
                    Dr. K. Saravanan
                  </div>
                  <div className="text-[8px] text-blue-300">Principal / COE</div>
                </div>
              </div>
            </div>
          ) : (
            /* BACK OF ID CARD */
            <div className="w-80 sm:w-88 bg-white text-slate-800 rounded-2xl shadow-xl overflow-hidden border border-slate-300 p-4 space-y-3 text-xs">
              <div className="border-b border-slate-200 pb-1.5 flex items-center justify-between">
                <span className="font-bold text-slate-900 uppercase tracking-wider text-[11px]">
                  Cardholder Emergency Info
                </span>
                <span className="font-mono font-bold text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded border border-rose-200 text-[10px]">
                  Blood: {student.bloodGroup}
                </span>
              </div>

              <div className="space-y-1.5 text-[11px] text-left">
                <div>
                  <span className="text-slate-500 font-medium">Date of Birth:</span>{' '}
                  <strong className="text-slate-900 font-mono">{student.dob} ({student.age} Yrs)</strong>
                </div>
                <div>
                  <span className="text-slate-500 font-medium">Father / Guardian:</span>{' '}
                  <strong className="text-slate-900">{student.fatherName}</strong>
                </div>
                <div>
                  <span className="text-slate-500 font-medium">Residential Address:</span>
                  <div className="text-slate-700 leading-tight mt-0.5">{student.address}</div>
                </div>
                <div>
                  <span className="text-slate-500 font-medium">Emergency Contact:</span>{' '}
                  <strong className="text-slate-900 font-mono">{student.phone}</strong>
                </div>
              </div>

              {/* Institution Terms */}
              <div className="p-2 bg-slate-50 rounded border border-slate-200 text-[9px] text-slate-500 leading-relaxed text-left">
                This card is the property of Excel Engineering College (Autonomous). It must be produced upon demand by college authorities and during examinations. If found, return to Office of the Registrar, Komarapalayam, Tamil Nadu - 637303.
              </div>

              <div className="text-center text-[10px] text-slate-400 font-mono">
                Helpline: 04288-227361 · www.excelcolleges.ac.in
              </div>
            </div>
          )}
        </div>

        {/* Informative Helper Note */}
        <div className="p-3 bg-blue-50/60 rounded-xl border border-blue-100 text-xs text-blue-900 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
          <span>Digital Student ID verified for library access, bus pass, and autonomous exam hall entry.</span>
        </div>
      </div>
    </div>
  );
};
