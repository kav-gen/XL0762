import React, { useState } from 'react';
import { 
  X, 
  User, 
  KeyRound, 
  Info, 
  CheckCircle2, 
  Phone, 
  Mail, 
  MapPin, 
  GraduationCap, 
  Calendar,
  Building,
  Shield,
  Printer,
  Copy,
  Check
} from 'lucide-react';
import { StudentProfile } from '../types/student';

interface ProfileDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  student: StudentProfile;
  onUpdateProfile: (updated: Partial<StudentProfile>) => void;
}

export const ProfileDrawer: React.FC<ProfileDrawerProps> = ({
  isOpen,
  onClose,
  student,
  onUpdateProfile
}) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'password' | 'moreInfo'>('profile');
  const [isCopied, setIsCopied] = useState(false);
  
  // Password change state
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState(false);

  if (!isOpen) return null;

  const handleCopyProfile = () => {
    const text = `Student: ${student.name}\nRoll No: ${student.rollNo}\nAdmission No: ${student.admissionNo}\nDept: ${student.department}\nCollege: ${student.college}`;
    navigator.clipboard.writeText(text);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword && newPassword === confirmPassword) {
      setPasswordSuccess(true);
      setTimeout(() => {
        setPasswordSuccess(false);
        setOldPassword('');
        setNewPassword('');
        setConfirmPassword('');
      }, 2500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/40 backdrop-blur-xs flex justify-end transition-opacity">
      <div 
        className="w-full max-w-xl bg-white h-full shadow-2xl flex flex-col border-l border-slate-200 animate-in slide-in-from-right duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Camu ERP Style Top Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-blue-100 border border-blue-200 flex items-center justify-center text-blue-700">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-slate-900 leading-tight">
                Student Profile & Records
              </h2>
              <p className="text-xs text-slate-500 font-mono">
                {student.college} (AUTONOMOUS)
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyProfile}
              className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-white rounded-md border border-slate-200 transition-colors"
              title="Copy Student Details"
            >
              {isCopied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-white rounded-md border border-slate-200 transition-colors"
              aria-label="Close Profile"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Camu-style Sub-navigation Tabs */}
        <div className="px-5 pt-3 pb-2 border-b border-slate-200 flex gap-2 bg-white">
          <button
            onClick={() => setActiveTab('profile')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'profile'
                ? 'bg-blue-50 text-blue-700 border border-blue-200'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Profile Details
          </button>
          <button
            onClick={() => setActiveTab('password')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'password'
                ? 'bg-blue-50 text-blue-700 border border-blue-200'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Change Password
          </button>
          <button
            onClick={() => setActiveTab('moreInfo')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'moreInfo'
                ? 'bg-blue-50 text-blue-700 border border-blue-200'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            More Info & Regulations
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-6">
          {activeTab === 'profile' && (
            <>
              {/* Photo & Primary Bio Card (As seen in camu.jpeg) */}
              <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 p-4 rounded-xl border border-slate-200 bg-slate-50/50">
                <div className="relative group shrink-0">
                  <div className="w-28 h-36 rounded-lg overflow-hidden border-2 border-white shadow-xs bg-white">
                    <img
                      src={student.avatarUrl}
                      alt={student.name}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="mt-1.5 text-center">
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                      {student.status}
                    </span>
                  </div>
                </div>

                <div className="flex-1 text-center sm:text-left space-y-1">
                  <div className="text-lg font-bold text-slate-900 tracking-tight">
                    {student.name}
                  </div>
                  <div className="text-xs text-slate-600 font-medium">
                    {student.courseName}
                  </div>
                  <div className="text-xs text-slate-500 font-mono">
                    Roll No: <span className="font-semibold text-slate-800">{student.rollNo}</span> · Adm: <span className="font-semibold text-slate-800">{student.admissionNo}</span>
                  </div>
                  <div className="text-xs text-slate-500">
                    Semester: <span className="font-semibold text-slate-800">{student.semester}</span> | Section: <span className="font-semibold text-slate-800">{student.section}</span> | {student.academicYear}
                  </div>

                  <div className="pt-2 flex flex-wrap gap-2 justify-center sm:justify-start text-xs text-slate-600">
                    <span className="inline-flex items-center gap-1 bg-white px-2 py-1 rounded border border-slate-200">
                      <Mail className="w-3 h-3 text-slate-400" />
                      {student.email}
                    </span>
                    <span className="inline-flex items-center gap-1 bg-white px-2 py-1 rounded border border-slate-200 font-mono">
                      <Phone className="w-3 h-3 text-slate-400" />
                      {student.phone}
                    </span>
                  </div>
                </div>
              </div>

              {/* Exact Camu ERP Academic Meta Table (camu.jpeg) */}
              <div>
                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                  Academic Classification
                </h3>
                <div className="border border-slate-200 rounded-lg overflow-hidden divide-y divide-slate-100 bg-white">
                  <div className="grid grid-cols-2 p-2.5 text-xs">
                    <span className="text-slate-500 font-medium">Student Status</span>
                    <span className="text-slate-900 font-semibold">{student.status}</span>
                  </div>
                  <div className="grid grid-cols-2 p-2.5 text-xs">
                    <span className="text-slate-500 font-medium">Admission No.</span>
                    <span className="text-slate-900 font-mono font-semibold">{student.admissionNo}</span>
                  </div>
                  <div className="grid grid-cols-2 p-2.5 text-xs">
                    <span className="text-slate-500 font-medium">Admission Year</span>
                    <span className="text-slate-900 font-mono">{student.admissionYear}</span>
                  </div>
                  <div className="grid grid-cols-2 p-2.5 text-xs">
                    <span className="text-slate-500 font-medium">Roll No.</span>
                    <span className="text-slate-900 font-mono font-semibold">{student.rollNo}</span>
                  </div>
                  <div className="grid grid-cols-2 p-2.5 text-xs">
                    <span className="text-slate-500 font-medium">Degree</span>
                    <span className="text-slate-900">{student.degree}</span>
                  </div>
                  <div className="grid grid-cols-2 p-2.5 text-xs">
                    <span className="text-slate-500 font-medium">Department</span>
                    <span className="text-slate-900 font-medium">{student.department}</span>
                  </div>
                  <div className="grid grid-cols-2 p-2.5 text-xs">
                    <span className="text-slate-500 font-medium">Semester</span>
                    <span className="text-slate-900 font-semibold">{student.semester}</span>
                  </div>
                  <div className="grid grid-cols-2 p-2.5 text-xs">
                    <span className="text-slate-500 font-medium">Section</span>
                    <span className="text-slate-900">{student.section}</span>
                  </div>
                  <div className="grid grid-cols-2 p-2.5 text-xs">
                    <span className="text-slate-500 font-medium">Course Name</span>
                    <span className="text-slate-900 font-medium">{student.courseName}</span>
                  </div>
                  <div className="grid grid-cols-2 p-2.5 text-xs">
                    <span className="text-slate-500 font-medium">College</span>
                    <span className="text-slate-900 font-semibold">{student.college}</span>
                  </div>
                  <div className="grid grid-cols-2 p-2.5 text-xs">
                    <span className="text-slate-500 font-medium">Curriculum Plan</span>
                    <span className="text-slate-900">{student.curriculumPlan}</span>
                  </div>
                  <div className="grid grid-cols-2 p-2.5 text-xs">
                    <span className="text-slate-500 font-medium">Academic Standing</span>
                    <span className="text-slate-900 font-semibold text-emerald-700">{student.academicStanding}</span>
                  </div>
                  <div className="grid grid-cols-2 p-2.5 text-xs">
                    <span className="text-slate-500 font-medium">Program Validity Date</span>
                    <span className="text-slate-900 font-mono">{student.programValidityDate}</span>
                  </div>
                </div>
              </div>

              {/* Exact Camu Personal & Parental Information (camu1.jpeg) */}
              <div>
                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                  Personal & Parental Details
                </h3>
                <div className="border border-slate-200 rounded-lg overflow-hidden divide-y divide-slate-100 bg-white">
                  <div className="grid grid-cols-2 p-2.5 text-xs">
                    <span className="text-slate-500 font-medium">Title</span>
                    <span className="text-slate-900">{student.title}</span>
                  </div>
                  <div className="grid grid-cols-2 p-2.5 text-xs">
                    <span className="text-slate-500 font-medium">First Name</span>
                    <span className="text-slate-900 font-semibold">{student.firstName}</span>
                  </div>
                  <div className="grid grid-cols-2 p-2.5 text-xs">
                    <span className="text-slate-500 font-medium">Last Name</span>
                    <span className="text-slate-900 font-semibold">{student.lastName}</span>
                  </div>
                  <div className="grid grid-cols-2 p-2.5 text-xs">
                    <span className="text-slate-500 font-medium">DOB</span>
                    <span className="text-slate-900 font-mono">{student.dob}</span>
                  </div>
                  <div className="grid grid-cols-2 p-2.5 text-xs">
                    <span className="text-slate-500 font-medium">Age</span>
                    <span className="text-slate-900 font-mono">{student.age} Years</span>
                  </div>
                  <div className="grid grid-cols-2 p-2.5 text-xs">
                    <span className="text-slate-500 font-medium">Gender</span>
                    <span className="text-slate-900">{student.gender}</span>
                  </div>
                  <div className="grid grid-cols-2 p-2.5 text-xs">
                    <span className="text-slate-500 font-medium">Father's Name</span>
                    <span className="text-slate-900 font-medium">{student.fatherName}</span>
                  </div>
                  <div className="grid grid-cols-2 p-2.5 text-xs">
                    <span className="text-slate-500 font-medium">Mother's Name</span>
                    <span className="text-slate-900 font-medium">{student.motherName}</span>
                  </div>
                  <div className="grid grid-cols-2 p-2.5 text-xs">
                    <span className="text-slate-500 font-medium">Address</span>
                    <span className="text-slate-900 leading-relaxed">{student.address}</span>
                  </div>
                  <div className="grid grid-cols-2 p-2.5 text-xs">
                    <span className="text-slate-500 font-medium">City</span>
                    <span className="text-slate-900">{student.city}</span>
                  </div>
                  <div className="grid grid-cols-2 p-2.5 text-xs">
                    <span className="text-slate-500 font-medium">State</span>
                    <span className="text-slate-900">{student.state}</span>
                  </div>
                </div>
              </div>

              {/* Academic Faculty Proctor Information */}
              <div className="p-3.5 bg-blue-50/60 rounded-lg border border-blue-100 flex items-start gap-3">
                <GraduationCap className="w-5 h-5 text-blue-700 shrink-0 mt-0.5" />
                <div className="text-xs space-y-0.5">
                  <div className="font-bold text-blue-900">Assigned Proctor & Class Advisor</div>
                  <div className="text-blue-800 font-medium">{student.mentorName}</div>
                  <div className="text-blue-600">{student.mentorCabin}</div>
                </div>
              </div>
            </>
          )}

          {activeTab === 'password' && (
            <form onSubmit={handlePasswordSubmit} className="space-y-4">
              <div className="p-3 bg-amber-50 rounded-lg border border-amber-200 text-xs text-amber-900">
                Passwords must be at least 8 characters and include uppercase, lowercase, numbers, and special characters.
              </div>

              {passwordSuccess && (
                <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  Password updated successfully in ERP database!
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Current Password
                </label>
                <input
                  type="password"
                  value={oldPassword}
                  onChange={(e) => setOldPassword(e.target.value)}
                  required
                  placeholder="••••••••••••"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-md focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  New Password
                </label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                  placeholder="••••••••••••"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-md focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Confirm New Password
                </label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  placeholder="••••••••••••"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-md focus:outline-hidden focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg transition-colors shadow-xs"
              >
                Update Password
              </button>
            </form>
          )}

          {activeTab === 'moreInfo' && (
            <div className="space-y-4 text-xs">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
                <div className="font-bold text-slate-900">Academic Regulations (Autonomous)</div>
                <p className="text-slate-600 leading-relaxed">
                  Excel Engineering College follows Choice Based Credit System (CBCS). To qualify for end-semester autonomous examinations, a minimum of 75% attendance in each course is strictly enforced.
                </p>
              </div>

              <div className="border border-slate-200 rounded-lg divide-y divide-slate-100 bg-white">
                <div className="p-3">
                  <div className="font-semibold text-slate-900">Discount & Scholarship Category</div>
                  <div className="text-slate-500 mt-0.5">{student.discountCategory}</div>
                </div>
                <div className="p-3">
                  <div className="font-semibold text-slate-900">Counseling Intake Stream</div>
                  <div className="text-slate-500 mt-0.5">{student.intake}</div>
                </div>
                <div className="p-3">
                  <div className="font-semibold text-slate-900">Emergency Blood Group</div>
                  <div className="text-slate-500 font-mono mt-0.5">{student.bloodGroup}</div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 text-center text-[11px] text-slate-500 font-mono">
          Camu Student Information System v4.9.2 · Autonomy Affiliation Anna Univ
        </div>
      </div>
    </div>
  );
};
