import React, { useState, useMemo } from 'react';
import { 
  Building2, 
  Users, 
  Award, 
  TrendingUp, 
  Briefcase, 
  BookOpen, 
  ShieldCheck, 
  Layers, 
  BarChart3, 
  Download, 
  Search, 
  Filter, 
  ChevronRight, 
  UserCheck, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  HelpCircle,
  FileSpreadsheet,
  GraduationCap,
  Sparkles,
  PieChart as PieIcon
} from 'lucide-react';
import { 
  Chart as ChartJS, 
  CategoryScale, 
  LinearScale, 
  BarElement, 
  PointElement, 
  LineElement, 
  ArcElement, 
  Title, 
  Tooltip, 
  Legend, 
  Filler 
} from 'chart.js';
import { Bar, Line, Doughnut } from 'react-chartjs-2';
import { 
  departmentStats, 
  sectionsComparisonData, 
  monthlyTrendsData, 
  facultyWorkloadData,
  FacultyWorkloadRecord,
  SectionComparisonMetric
} from '../../data/hodViewData';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

export const HodDashboardView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'overview' | 'sections' | 'faculty'>('overview');
  const [selectedSection, setSelectedSection] = useState<'ALL' | 'A' | 'B' | 'C' | 'D'>('ALL');
  const [facultySearch, setFacultySearch] = useState<string>('');
  const [designationFilter, setDesignationFilter] = useState<string>('ALL');
  const [workloadStatusFilter, setWorkloadStatusFilter] = useState<string>('ALL');

  // Filtered faculty records
  const filteredFaculty = useMemo(() => {
    return facultyWorkloadData.filter(fac => {
      const matchesSearch = 
        fac.name.toLowerCase().includes(facultySearch.toLowerCase()) ||
        fac.specialization.toLowerCase().includes(facultySearch.toLowerCase()) ||
        fac.assignedSubjects.some(sub => sub.toLowerCase().includes(facultySearch.toLowerCase()));
      const matchesDesig = designationFilter === 'ALL' || fac.designation === designationFilter;
      const matchesStatus = workloadStatusFilter === 'ALL' || fac.workloadStatus === workloadStatusFilter;
      return matchesSearch && matchesDesig && matchesStatus;
    });
  }, [facultySearch, designationFilter, workloadStatusFilter]);

  // Section comparison Bar Chart Data
  const sectionMetricsBarData = {
    labels: ['Section A (128)', 'Section B (124)', 'Section C (126)', 'Section D (122)'],
    datasets: [
      {
        label: 'Pass Rate (%)',
        data: sectionsComparisonData.map(s => s.passPercentage),
        backgroundColor: '#1d4ed8', // Royal Blue
        borderRadius: 6,
      },
      {
        label: 'Attendance Rate (%)',
        data: sectionsComparisonData.map(s => s.attendancePercentage),
        backgroundColor: '#3b82f6', // Bright Blue
        borderRadius: 6,
      },
      {
        label: 'Placement Readiness (%)',
        data: sectionsComparisonData.map(s => s.placementReadiness),
        backgroundColor: '#10b981', // Emerald
        borderRadius: 6,
      },
      {
        label: 'Internal Assessment Avg (%)',
        data: sectionsComparisonData.map(s => s.internalAssessmentAvg),
        backgroundColor: '#f59e0b', // Amber
        borderRadius: 6,
      }
    ]
  };

  const barChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          font: { family: 'Plus Jakarta Sans', size: 11, weight: 'bold' as const },
          usePointStyle: true,
          boxWidth: 8
        }
      },
      tooltip: {
        callbacks: {
          label: (ctx: any) => `${ctx.dataset.label}: ${ctx.raw}%`
        }
      }
    },
    scales: {
      y: {
        min: 60,
        max: 100,
        grid: { color: '#f1f5f9' },
        ticks: {
          callback: (val: any) => `${val}%`,
          font: { family: 'JetBrains Mono', size: 10 }
        }
      },
      x: {
        grid: { display: false },
        ticks: {
          font: { family: 'Plus Jakarta Sans', size: 11, weight: 'bold' as const }
        }
      }
    }
  };

  // Monthly Attendance Line Chart
  const monthlyTrendLineData = {
    labels: monthlyTrendsData.months,
    datasets: [
      {
        label: 'Section A',
        data: monthlyTrendsData.attendanceBySection.secA,
        borderColor: '#1d4ed8',
        backgroundColor: 'rgba(29, 78, 216, 0.08)',
        fill: true,
        tension: 0.35,
        borderWidth: 2.5,
        pointRadius: 4,
        pointBackgroundColor: '#1d4ed8'
      },
      {
        label: 'Section B',
        data: monthlyTrendsData.attendanceBySection.secB,
        borderColor: '#0284c7',
        backgroundColor: 'transparent',
        tension: 0.35,
        borderWidth: 2,
        pointRadius: 3
      },
      {
        label: 'Section C',
        data: monthlyTrendsData.attendanceBySection.secC,
        borderColor: '#10b981',
        backgroundColor: 'transparent',
        tension: 0.35,
        borderWidth: 2,
        pointRadius: 3
      },
      {
        label: 'Section D',
        data: monthlyTrendsData.attendanceBySection.secD,
        borderColor: '#f59e0b',
        backgroundColor: 'transparent',
        tension: 0.35,
        borderWidth: 2,
        pointRadius: 3
      }
    ]
  };

  const lineChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          font: { family: 'Plus Jakarta Sans', size: 11, weight: 'bold' as const },
          usePointStyle: true,
          boxWidth: 8
        }
      }
    },
    scales: {
      y: {
        min: 75,
        max: 100,
        grid: { color: '#f1f5f9' },
        ticks: {
          callback: (val: any) => `${val}%`,
          font: { family: 'JetBrains Mono', size: 10 }
        }
      },
      x: {
        grid: { display: false },
        ticks: {
          font: { family: 'Plus Jakarta Sans', size: 11 }
        }
      }
    }
  };

  // Grade Distribution Doughnut Chart for Section A vs All
  const gradeDoughnutData = {
    labels: ['O Grade (Outstanding)', 'A+ Grade (Excellent)', 'A Grade (Very Good)', 'B+ Grade (Good)', 'B Grade (Above Avg)', 'Arrears'],
    datasets: [
      {
        data: [78, 149, 168, 71, 24, 10], // Total sum across 500 students
        backgroundColor: [
          '#1d4ed8', // Royal Blue (O)
          '#3b82f6', // Light Blue (A+)
          '#06b6d4', // Cyan (A)
          '#10b981', // Emerald (B+)
          '#f59e0b', // Amber (B)
          '#ef4444'  // Rose (Arrears)
        ],
        borderWidth: 2,
        borderColor: '#ffffff'
      }
    ]
  };

  // Faculty Workload Distribution Bar Chart (Top 10 Faculty Load)
  const facultyLoadChartData = {
    labels: facultyWorkloadData.slice(0, 10).map(f => f.name.replace('Dr. ', '').replace('Prof. ', '')),
    datasets: [
      {
        label: 'Theory Hours/wk',
        data: facultyWorkloadData.slice(0, 10).map(f => f.theoryHours),
        backgroundColor: '#1d4ed8',
        stack: 'Load'
      },
      {
        label: 'Lab Hours/wk',
        data: facultyWorkloadData.slice(0, 10).map(f => f.labHours),
        backgroundColor: '#60a5fa',
        stack: 'Load'
      },
      {
        label: 'Mentoring & Admin/wk',
        data: facultyWorkloadData.slice(0, 10).map(f => f.mentoringAndAdminHours),
        backgroundColor: '#93c5fd',
        stack: 'Load'
      }
    ]
  };

  const handleExportFacultyReport = () => {
    const headers = ['Faculty Name', 'Designation', 'Qualification', 'Theory Hrs', 'Lab Hrs', 'Admin Hrs', 'Total Hrs/Wk', 'Status', 'Mentees'];
    const rows = filteredFaculty.map(f => [
      `"${f.name}"`,
      `"${f.designation}"`,
      `"${f.qualification}"`,
      f.theoryHours,
      f.labHours,
      f.mentoringAndAdminHours,
      f.totalHours,
      f.workloadStatus,
      f.assignedMenteesCount
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const link = document.createElement('a');
    link.setAttribute('href', encodeURI(csvContent));
    link.setAttribute('download', 'HOD_Faculty_Workload_Analytics.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top HOD Banner & Header */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-blue-700 to-blue-900 text-white flex items-center justify-center font-bold text-xl shadow-md shrink-0 border border-blue-800">
              <Building2 className="w-7 h-7" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2 mb-1">
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800 border border-blue-300">
                  Head of Department (HOD) Portal
                </span>
                <span className="text-xs font-mono text-slate-500">
                  {departmentStats.college}
                </span>
                <span className="text-xs font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" /> NAAC A+ & NBA Tier-1 Accreditation
                </span>
              </div>
              <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                Department of {departmentStats.departmentName}
              </h1>
              <p className="text-xs sm:text-sm text-slate-600 mt-0.5">
                Executive Overview · <strong>{departmentStats.hodName}</strong> ({departmentStats.hodCabin})
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              onClick={handleExportFacultyReport}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              Export HOD Report (CSV)
            </button>
            <div className="text-right pl-3 border-l border-slate-200 hidden sm:block">
              <div className="text-[11px] font-mono text-slate-500 uppercase tracking-wider">Department Ratio</div>
              <div className="text-xs font-bold text-slate-800">{departmentStats.facultySummary.studentFacultyRatio}</div>
            </div>
          </div>
        </div>

        {/* 6 High-Level Department Stats Cards (500 Students Enrolled) */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-6 pt-5 border-t border-slate-100">
          <div className="p-3 bg-blue-50/70 rounded-xl border border-blue-200">
            <div className="flex items-center justify-between text-blue-800 mb-1">
              <span className="text-xs font-semibold">Total Enrolled</span>
              <Users className="w-4 h-4" />
            </div>
            <div className="text-2xl font-extrabold text-blue-900">{departmentStats.totalStudents}</div>
            <div className="text-[11px] text-blue-700 mt-0.5">Across 4 Batches</div>
          </div>

          <div className="p-3 bg-emerald-50/70 rounded-xl border border-emerald-200">
            <div className="flex items-center justify-between text-emerald-800 mb-1">
              <span className="text-xs font-semibold">Dept Pass Rate</span>
              <Award className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="text-2xl font-extrabold text-emerald-900">{departmentStats.overallPassPercentage}%</div>
            <div className="text-[11px] text-emerald-700 mt-0.5">↑ {departmentStats.passPercentageDelta} vs last sem</div>
          </div>

          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <div className="flex items-center justify-between text-slate-700 mb-1">
              <span className="text-xs font-semibold">Average CGPA</span>
              <GraduationCap className="w-4 h-4 text-slate-600" />
            </div>
            <div className="text-2xl font-extrabold text-slate-900">{departmentStats.departmentAvgCgpa}</div>
            <div className="text-[11px] text-slate-500 mt-0.5">Scale of 10.0</div>
          </div>

          <div className="p-3 bg-blue-50/50 rounded-xl border border-blue-100">
            <div className="flex items-center justify-between text-blue-700 mb-1">
              <span className="text-xs font-semibold">Dept Attendance</span>
              <UserCheck className="w-4 h-4 text-blue-600" />
            </div>
            <div className="text-2xl font-extrabold text-blue-800">{departmentStats.departmentAvgAttendance}%</div>
            <div className="text-[11px] text-blue-600 mt-0.5">Condonation Cutoff: 75%</div>
          </div>

          <div className="p-3 bg-amber-50/70 rounded-xl border border-amber-200">
            <div className="flex items-center justify-between text-amber-800 mb-1">
              <span className="text-xs font-semibold">Placement Rate</span>
              <Briefcase className="w-4 h-4 text-amber-600" />
            </div>
            <div className="text-2xl font-extrabold text-amber-900">{departmentStats.placementStats.placementPercentage}%</div>
            <div className="text-[11px] text-amber-700 mt-0.5">{departmentStats.placementStats.placedStudents} Placed (Top {departmentStats.placementStats.highestCtc})</div>
          </div>

          <div className="p-3 bg-indigo-50/70 rounded-xl border border-indigo-200">
            <div className="flex items-center justify-between text-indigo-800 mb-1">
              <span className="text-xs font-semibold">Faculty Strength</span>
              <BookOpen className="w-4 h-4 text-indigo-600" />
            </div>
            <div className="text-2xl font-extrabold text-indigo-900">{departmentStats.facultySummary.totalFaculty}</div>
            <div className="text-[11px] text-indigo-700 mt-0.5">{departmentStats.facultySummary.doctoratesCount} Ph.D Holders</div>
          </div>
        </div>
      </div>

      {/* Primary HOD Sub-View Navigation */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-2">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-lg transition-all flex items-center gap-2 ${
              activeTab === 'overview'
                ? 'bg-blue-700 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            Section-wise Analytics (Sec A, B, C, D)
          </button>

          <button
            onClick={() => setActiveTab('sections')}
            className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-lg transition-all flex items-center gap-2 ${
              activeTab === 'sections'
                ? 'bg-blue-700 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Layers className="w-4 h-4" />
            Section Performance Matrix
          </button>

          <button
            onClick={() => setActiveTab('faculty')}
            className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-lg transition-all flex items-center gap-2 ${
              activeTab === 'faculty'
                ? 'bg-blue-700 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Users className="w-4 h-4" />
            Faculty Workload Analytics ({facultyWorkloadData.length})
          </button>
        </div>
      </div>

      {/* VIEW 1: Section-wise Comparison Charts (Chart.js) */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Main Chart Row 1: Section Performance Multi-Metric Bar & Grade Doughnut */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* 2 Cols: Section-wise Comparison Bar Chart */}
            <div className="lg:col-span-2 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-slate-900 flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-blue-700" />
                    Section Comparison: Pass Rate, Attendance, Placement & CIA Avg
                  </h3>
                  <p className="text-xs text-slate-500">
                    Comparative metric benchmark across Sections A (128), B (124), C (126), and D (122)
                  </p>
                </div>
                <span className="text-xs font-mono font-bold text-blue-700 bg-blue-50 px-2 py-1 rounded">
                  500 Total Students
                </span>
              </div>

              <div className="h-72 w-full pt-2">
                <Bar data={sectionMetricsBarData} options={barChartOptions} />
              </div>
            </div>

            {/* 1 Col: Overall Grade Distribution Doughnut Chart */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4 flex flex-col justify-between">
              <div>
                <h3 className="text-sm sm:text-base font-bold text-slate-900 flex items-center gap-2">
                  <PieIcon className="w-4 h-4 text-blue-700" />
                  Department Academic Grade Distribution
                </h3>
                <p className="text-xs text-slate-500">
                  Cumulative semester grading distribution across all 500 CSBS students
                </p>
              </div>

              <div className="h-56 w-full flex items-center justify-center pt-2">
                <Doughnut 
                  data={gradeDoughnutData} 
                  options={{
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        position: 'bottom',
                        labels: {
                          boxWidth: 8,
                          font: { family: 'Plus Jakarta Sans', size: 10 }
                        }
                      }
                    }
                  }} 
                />
              </div>

              <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-600 flex items-center justify-between">
                <span>Distinction (O + A+): <strong>227 (45.4%)</strong></span>
                <span className="text-rose-600 font-bold">Total Arrears: 10 (2.0%)</span>
              </div>
            </div>
          </div>

          {/* Main Chart Row 2: Monthly Attendance Trend Line Chart across 4 Sections */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h3 className="text-sm sm:text-base font-bold text-slate-900 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-blue-700" />
                  Monthly Attendance & Academic Velocity Tracking (Aug - Mar)
                </h3>
                <p className="text-xs text-slate-500">
                  8-month tracking curve highlighting section trends against institutional 75% threshold
                </p>
              </div>
              <div className="flex items-center gap-2 text-xs font-semibold">
                <span className="w-3 h-3 rounded-full bg-blue-700 inline-block"></span> Sec A
                <span className="w-3 h-3 rounded-full bg-sky-600 inline-block ml-1"></span> Sec B
                <span className="w-3 h-3 rounded-full bg-emerald-500 inline-block ml-1"></span> Sec C
                <span className="w-3 h-3 rounded-full bg-amber-500 inline-block ml-1"></span> Sec D
              </div>
            </div>

            <div className="h-64 w-full pt-2">
              <Line data={monthlyTrendLineData} options={lineChartOptions} />
            </div>
          </div>
        </div>
      )}

      {/* VIEW 2: Section Performance Scorecards & Comparative Table */}
      {(activeTab === 'sections' || activeTab === 'overview') && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Layers className="w-4 h-4 text-blue-700" />
              Section-wise Operational Performance Scorecards
            </h3>
            <span className="text-xs text-slate-500">Sections A, B, C, D</span>
          </div>

          {/* 4 Section Scorecards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {sectionsComparisonData.map((sec) => (
              <div 
                key={sec.sectionId}
                className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:border-blue-300 transition-all space-y-4"
              >
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div>
                    <h4 className="font-extrabold text-base text-slate-900">{sec.sectionName}</h4>
                    <p className="text-xs text-slate-500">{sec.roomNumber} · {sec.totalStudents} Students</p>
                  </div>
                  <span className="w-8 h-8 rounded-lg bg-blue-50 text-blue-700 font-bold flex items-center justify-center border border-blue-200">
                    {sec.sectionId}
                  </span>
                </div>

                <div className="text-xs space-y-1">
                  <div className="text-slate-500">Class Advisor:</div>
                  <div className="font-bold text-slate-800">{sec.classAdvisor}</div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="p-2.5 bg-blue-50/50 rounded-lg border border-blue-100">
                    <div className="text-[10px] text-blue-700 font-semibold">Pass Rate</div>
                    <div className="text-base font-bold text-blue-900 font-mono">{sec.passPercentage}%</div>
                  </div>
                  <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                    <div className="text-[10px] text-slate-500 font-semibold">Avg CGPA</div>
                    <div className="text-base font-bold text-slate-900 font-mono">{sec.avgCgpa}</div>
                  </div>
                  <div className="p-2.5 bg-emerald-50/50 rounded-lg border border-emerald-100">
                    <div className="text-[10px] text-emerald-700 font-semibold">Attendance</div>
                    <div className="text-base font-bold text-emerald-900 font-mono">{sec.attendancePercentage}%</div>
                  </div>
                  <div className="p-2.5 bg-amber-50/50 rounded-lg border border-amber-100">
                    <div className="text-[10px] text-amber-700 font-semibold">Placement</div>
                    <div className="text-base font-bold text-amber-900 font-mono">{sec.placementReadiness}%</div>
                  </div>
                </div>

                <div className="text-xs pt-2 border-t border-slate-100 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">At-Risk Students:</span>
                    <span className="font-bold text-rose-600 font-mono">{sec.atRiskCount} Students</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Top Ranker:</span>
                    <span className="font-semibold text-slate-800 text-[11px] truncate max-w-[140px]">{sec.topStudent}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* VIEW 3: Faculty Workload Analytics (24 Faculty Members) */}
      {activeTab === 'faculty' && (
        <div className="space-y-6">
          {/* Workload Distribution Chart */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h3 className="text-sm sm:text-base font-bold text-slate-900 flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-blue-700" />
                  Faculty Workload Breakdown (Theory vs Lab vs Mentoring Hours)
                </h3>
                <p className="text-xs text-slate-500">
                  AICTE Workload Standard: Maximum 18–20 hours/week per faculty member
                </p>
              </div>
              <span className="text-xs font-mono font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200">
                AICTE Norms Compliant
              </span>
            </div>

            <div className="h-64 w-full pt-2">
              <Bar 
                data={facultyLoadChartData} 
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  scales: {
                    x: { stacked: true, grid: { display: false } },
                    y: { 
                      stacked: true, 
                      max: 25,
                      ticks: { callback: (v: any) => `${v}h` },
                      grid: { color: '#f1f5f9' }
                    }
                  },
                  plugins: {
                    legend: { position: 'top', labels: { boxWidth: 8, font: { family: 'Plus Jakarta Sans', size: 10 } } }
                  }
                }} 
              />
            </div>
          </div>

          {/* Faculty Controls: Search, Designation, Load Status */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search across 24 faculty (name, subject, specialization)..."
                value={facultySearch}
                onChange={(e) => setFacultySearch(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2 text-xs">
              <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
                <span className="text-[11px] font-bold text-slate-500 px-1">Designation:</span>
                {['ALL', 'Professor', 'Associate Professor', 'Assistant Professor'].map((d) => (
                  <button
                    key={d}
                    onClick={() => setDesignationFilter(d)}
                    className={`px-2 py-1 rounded-md font-semibold transition-colors ${
                      designationFilter === d ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600'
                    }`}
                  >
                    {d === 'Associate Professor' ? 'Assoc Prof' : d === 'Assistant Professor' ? 'Asst Prof' : d}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
                <span className="text-[11px] font-bold text-slate-500 px-1">Load:</span>
                {['ALL', 'OPTIMAL', 'FULL LOAD', 'OVERLOAD', 'UNDERLOAD'].map((st) => (
                  <button
                    key={st}
                    onClick={() => setWorkloadStatusFilter(st)}
                    className={`px-2 py-1 rounded-md font-semibold transition-colors ${
                      workloadStatusFilter === st ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* 24 Faculty Workload Roster Table */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-slate-50/90 text-slate-600 font-bold border-b border-slate-200 uppercase tracking-wider text-[11px]">
                  <tr>
                    <th className="px-4 py-3">Faculty Member</th>
                    <th className="px-3 py-3">Designation & Degree</th>
                    <th className="px-3 py-3">Theory Hrs/Wk</th>
                    <th className="px-3 py-3">Lab Hrs/Wk</th>
                    <th className="px-3 py-3">Total Workload</th>
                    <th className="px-3 py-3">Load Status</th>
                    <th className="px-4 py-3 min-w-[200px]">Assigned Course(s)</th>
                    <th className="px-3 py-3">Mentees</th>
                    <th className="px-3 py-3">Publications</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredFaculty.map((fac) => (
                    <tr key={fac.id} className="hover:bg-blue-50/30 transition-colors">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={fac.photoUrl}
                            alt={fac.name}
                            className="w-8 h-8 rounded-full object-cover border border-slate-200 shrink-0"
                          />
                          <div>
                            <div className="font-bold text-slate-900 text-xs sm:text-sm">
                              {fac.name}
                            </div>
                            <div className="text-[11px] text-slate-500 font-mono">
                              Exp: {fac.experienceYears} Years · {fac.specialization}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-3 py-3">
                        <div className="font-semibold text-slate-800">{fac.designation}</div>
                        <div className="text-[10px] text-slate-500 font-mono">{fac.qualification}</div>
                      </td>
                      <td className="px-3 py-3 font-mono font-bold text-slate-800">
                        {fac.theoryHours} hrs
                      </td>
                      <td className="px-3 py-3 font-mono font-bold text-slate-800">
                        {fac.labHours} hrs
                      </td>
                      <td className="px-3 py-3">
                        <span className="font-mono font-extrabold text-blue-900 text-sm">
                          {fac.totalHours} hrs/wk
                        </span>
                      </td>
                      <td className="px-3 py-3">
                        {fac.workloadStatus === 'OPTIMAL' && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                            Optimal (16–18h)
                          </span>
                        )}
                        {fac.workloadStatus === 'FULL LOAD' && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-800">
                            Full Load (19–20h)
                          </span>
                        )}
                        {fac.workloadStatus === 'OVERLOAD' && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800">
                            Overload (&gt;20h)
                          </span>
                        )}
                        {fac.workloadStatus === 'UNDERLOAD' && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800">
                            Underload (&lt;16h)
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex flex-wrap gap-1">
                          {fac.assignedSubjects.map((sub, i) => (
                            <span key={i} className="text-[10px] px-1.5 py-0.2 bg-slate-100 text-slate-700 rounded font-medium">
                              {sub}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="px-3 py-3 font-mono font-bold text-slate-700">
                        {fac.assignedMenteesCount} Students
                      </td>
                      <td className="px-3 py-3 font-mono text-slate-600">
                        {fac.publicationsThisYear} Papers
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
