import React, { useState } from 'react';
import { 
  MessageSquare, 
  Star, 
  Send, 
  CheckCircle2, 
  User, 
  GraduationCap, 
  Clock, 
  HelpCircle
} from 'lucide-react';
import { mentorNotes } from '../data/studentData';

export const FeedbackSection: React.FC = () => {
  const [selectedCourse, setSelectedCourse] = useState('CB302: Design & Analysis of Algorithms');
  const [ratingClarity, setRatingClarity] = useState(5);
  const [ratingPacing, setRatingPacing] = useState(5);
  const [ratingLab, setRatingLab] = useState(4);
  const [comments, setComments] = useState('');
  const [submittedFeedback, setSubmittedFeedback] = useState(false);

  // Proctor request
  const [proctorMessage, setProctorMessage] = useState('');
  const [proctorSubmitted, setProctorSubmitted] = useState(false);

  const handleSubmitFeedback = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmittedFeedback(true);
    setTimeout(() => {
      setSubmittedFeedback(false);
      setComments('');
    }, 3000);
  };

  const handleProctorRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!proctorMessage.trim()) return;
    setProctorSubmitted(true);
    setTimeout(() => {
      setProctorSubmitted(false);
      setProctorMessage('');
    }, 3000);
  };

  return (
    <div className="space-y-6">
      {/* Mentor & Advisor Remarks (Faculty to Student) */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <GraduationCap className="w-4 h-4 text-blue-600" />
              Proctoring Committee & Class Advisor Official Log
            </h3>
            <p className="text-xs text-slate-500">
              Formal evaluations from Dr. K. Saravanan and Department Head Dr. P. Kavitha.
            </p>
          </div>
          <span className="text-xs font-semibold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 self-start sm:self-auto">
            All Reviews Satisfactory
          </span>
        </div>

        <div className="space-y-3">
          {mentorNotes.map((note, idx) => (
            <div key={idx} className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2 text-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                <span className="font-bold text-slate-900">{note.faculty}</span>
                <span className="text-slate-500 font-mono text-[11px]">{note.date}</span>
              </div>
              <div className="text-[11px] font-semibold text-blue-700">
                Category: {note.category}
              </div>
              <p className="text-slate-700 leading-relaxed">
                "{note.content}"
              </p>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Student to Faculty Feedback Form */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 space-y-4">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-blue-600" />
              Submit End-Semester Faculty & Course Feedback
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Camu Autonomous student satisfaction survey (Confidential).
            </p>
          </div>

          {submittedFeedback ? (
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 text-center space-y-1">
              <CheckCircle2 className="w-6 h-6 text-emerald-600 mx-auto" />
              <div className="font-bold">Course Feedback Recorded</div>
              <div className="text-slate-600">Your evaluation has been anonymized and submitted to the Academic Dean.</div>
            </div>
          ) : (
            <form onSubmit={handleSubmitFeedback} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Select Course:</label>
                <select
                  value={selectedCourse}
                  onChange={(e) => setSelectedCourse(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium"
                >
                  <option>CB301: Discrete Mathematics & Combinatorics</option>
                  <option>CB302: Design & Analysis of Algorithms</option>
                  <option>CB303: Operating Systems & System Calls</option>
                  <option>CB304: Fundamentals of Business Systems</option>
                  <option>CB305: Database Management Systems & NoSQL</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Conceptual Clarity & Explanation (1-5):</label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRatingClarity(star)}
                      className={`px-3 py-1.5 rounded border text-xs font-mono font-bold ${
                        ratingClarity >= star 
                          ? 'bg-blue-600 text-white border-blue-600' 
                          : 'bg-slate-50 text-slate-600 border-slate-200'
                      }`}
                    >
                      {star}★
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Syllabus Pacing & Timely Doubts Clearing (1-5):</label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRatingPacing(star)}
                      className={`px-3 py-1.5 rounded border text-xs font-mono font-bold ${
                        ratingPacing >= star 
                          ? 'bg-blue-600 text-white border-blue-600' 
                          : 'bg-slate-50 text-slate-600 border-slate-200'
                      }`}
                    >
                      {star}★
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Qualitative Feedback / Suggestions:</label>
                <textarea
                  rows={2}
                  value={comments}
                  onChange={(e) => setComments(e.target.value)}
                  placeholder="E.g., Exceptional algorithm walkthroughs, more practical graph problems recommended."
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg shadow-xs transition-colors"
              >
                Submit Course Evaluation
              </button>
            </form>
          )}
        </div>

        {/* Proctor Appointment & Grievance Request */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 space-y-4">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <User className="w-4 h-4 text-slate-700" />
              Request 1-on-1 Proctor Counseling
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Direct communication line with Dr. K. Saravanan (Class Advisor).
            </p>
          </div>

          {proctorSubmitted ? (
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 text-center space-y-1">
              <CheckCircle2 className="w-6 h-6 text-emerald-600 mx-auto" />
              <div className="font-bold">Counseling Request Logged</div>
              <div className="text-slate-600">The advisor will assign a slot during Thursday proctor hour (Room 304).</div>
            </div>
          ) : (
            <form onSubmit={handleProctorRequest} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Discussion Subject:</label>
                <select className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs">
                  <option>Super-Dream Placement Preparation Guidance</option>
                  <option>On-Duty (OD) Regularization Review</option>
                  <option>Elective Course Selection for SEM-4</option>
                  <option>Hackathon Travel Grant Approval</option>
                  <option>General Academic Counseling</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Message for Faculty Proctor:</label>
                <textarea
                  rows={4}
                  required
                  value={proctorMessage}
                  onChange={(e) => setProctorMessage(e.target.value)}
                  placeholder="Describe your query or preferred discussion time..."
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-lg shadow-xs transition-colors flex items-center justify-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                Submit Request to Proctor
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
