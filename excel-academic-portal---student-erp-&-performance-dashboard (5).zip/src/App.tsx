/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Header, PortalRole } from './components/Header';
import { OverviewSection } from './components/OverviewSection';
import { AcademicSection } from './components/AcademicSection';
import { AttendanceSection } from './components/AttendanceSection';
import { PlacementSection } from './components/PlacementSection';
import { LmsSection } from './components/LmsSection';
import { SkillsSection } from './components/SkillsSection';
import { SegmentationSection } from './components/SegmentationSection';
import { FeedbackSection } from './components/FeedbackSection';
import { ProfileDrawer } from './components/ProfileDrawer';
import { SourceCodeModal } from './components/SourceCodeModal';
import { PrintGradeCard } from './components/PrintGradeCard';
import { StudentIDCardModal } from './components/StudentIDCardModal';
import { ZoroCopilot } from './components/ZoroCopilot';

// Staff & HOD Dashboard Views
import { StaffDashboardView } from './components/staff/StaffDashboardView';
import { HodDashboardView } from './components/hod/HodDashboardView';

import { 
  initialStudentProfile, 
  academicRecords, 
  attendanceData, 
  placementMetrics, 
  lmsCourses, 
  assignmentsList, 
  skillsInventory, 
  certificationsList, 
  studentSegments 
} from './data/studentData';
import { StudentProfile } from './types/student';

export default function App() {
  // Current active role: 'student' | 'staff' | 'hod'
  const [currentRole, setCurrentRole] = useState<PortalRole>('student');
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [student, setStudent] = useState<StudentProfile>(initialStudentProfile);
  const [isProfileOpen, setIsProfileOpen] = useState<boolean>(false);
  const [isStudentIDOpen, setIsStudentIDOpen] = useState<boolean>(false);
  const [isSourceCodeOpen, setIsSourceCodeOpen] = useState<boolean>(false);
  const [isPrintCardOpen, setIsPrintCardOpen] = useState<boolean>(false);

  const handleUpdateProfile = (updated: Partial<StudentProfile>) => {
    setStudent(prev => ({ ...prev, ...updated }));
  };

  return (
    <div className="min-h-screen bg-slate-50/60 text-slate-800 flex flex-col antialiased selection:bg-blue-100 selection:text-blue-900">
      {/* Top Professional Institutional Header with Role Switcher Dropdown */}
      <Header
        currentRole={currentRole}
        onRoleChange={setCurrentRole}
        student={student}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onOpenProfile={() => setIsProfileOpen(true)}
        onOpenStudentID={() => setIsStudentIDOpen(true)}
        onPrintTranscript={() => setIsPrintCardOpen(true)}
      />

      {/* Main Viewport Content Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* 1. STUDENT VIEW: All 6 Core Tabs for MENMITHA S Preserved */}
        {currentRole === 'student' && (
          <div>
            {activeTab === 'overview' && (
              <OverviewSection
                student={student}
                academic={academicRecords}
                attendance={attendanceData}
                placement={placementMetrics}
                onNavigateTab={setActiveTab}
                onOpenProfile={() => setIsProfileOpen(true)}
              />
            )}

            {activeTab === 'academic' && (
              <AcademicSection
                records={academicRecords}
                onOpenSourceCode={() => setIsSourceCodeOpen(true)}
              />
            )}

            {activeTab === 'attendance' && (
              <AttendanceSection
                data={attendanceData}
              />
            )}

            {activeTab === 'placement' && (
              <PlacementSection
                metrics={placementMetrics}
              />
            )}

            {activeTab === 'lms' && (
              <LmsSection
                courses={lmsCourses}
                assignments={assignmentsList}
              />
            )}

            {activeTab === 'segmentation' && (
              <SegmentationSection
                segments={studentSegments}
                currentStudent={student}
              />
            )}

            {activeTab === 'skills' && (
              <SkillsSection
                skills={skillsInventory}
                certifications={certificationsList}
              />
            )}

            {activeTab === 'feedback' && (
              <FeedbackSection />
            )}
          </div>
        )}

        {/* 2. STAFF VIEW: 60 Assigned Students & AI Early Warning Risk Queue */}
        {currentRole === 'staff' && (
          <StaffDashboardView />
        )}

        {/* 3. HOD VIEW: 500 Dept Students, Section Comparison Charts & Faculty Workload */}
        {currentRole === 'hod' && (
          <HodDashboardView />
        )}
      </main>

      {/* Institutional Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 text-xs text-slate-500 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-center sm:text-left space-y-0.5">
            <div className="font-bold text-slate-800">
              {student.college} (AUTONOMOUS)
            </div>
            <p>
              Accredited with 'A+' Grade by NAAC · Approved by AICTE · Affiliated to Anna University, Chennai
            </p>
          </div>

          <div className="flex items-center gap-4 text-xs font-medium">
            <button
              onClick={() => setIsStudentIDOpen(true)}
              className="text-blue-700 hover:text-blue-900 hover:underline"
            >
              Student ID Card
            </button>
            <span>·</span>
            <button
              onClick={() => setIsSourceCodeOpen(true)}
              className="text-slate-600 hover:text-slate-900 hover:underline"
            >
              Export Code
            </button>
            <span>·</span>
            <button
              onClick={() => setIsProfileOpen(true)}
              className="text-slate-600 hover:text-slate-900 hover:underline"
            >
              Camu Student Profile
            </button>
            <span>·</span>
            <span className="font-mono text-slate-400">
              Camu SIS Engine v4.9.2
            </span>
          </div>
        </div>
      </footer>

      {/* Student Identity Card Modal */}
      <StudentIDCardModal
        isOpen={isStudentIDOpen}
        onClose={() => setIsStudentIDOpen(false)}
        student={student}
      />

      {/* Zoro Academic & Motivation Copilot */}
      <ZoroCopilot
        student={student}
      />

      {/* Camu Profile Drawer / Modal */}
      <ProfileDrawer
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        student={student}
        onUpdateProfile={handleUpdateProfile}
      />

      {/* Source Code Viewer & Exporter */}
      <SourceCodeModal
        isOpen={isSourceCodeOpen}
        onClose={() => setIsSourceCodeOpen(false)}
      />

      {/* Official Autonomous Marksheet / Grade Transcript Modal */}
      {isPrintCardOpen && (
        <PrintGradeCard
          student={student}
          records={academicRecords}
          onClose={() => setIsPrintCardOpen(false)}
        />
      )}
    </div>
  );
}
