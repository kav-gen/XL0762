import { 
  StudentProfile, 
  SemesterRecord, 
  AttendanceRecord, 
  LMSCourse, 
  Assignment, 
  PlacementMetric, 
  SkillItem, 
  Certification, 
  StudentSegment 
} from '../types/student';

// Real data from Camu ERP screenshots
export const initialStudentProfile: StudentProfile = {
  id: '25CB033',
  name: 'MENMITHA S',
  title: 'Ms.',
  firstName: 'MENMITHA',
  lastName: 'S',
  status: 'Active',
  admissionNo: '25EGCSBS032',
  admissionYear: '2025-26',
  rollNo: '25CB033',
  degree: 'Under Graduate',
  department: 'Computer Science and Business System',
  courseName: 'B.Tech- Computer Science and Business System',
  college: 'Excel Engineering College (AUTONOMOUS)',
  semester: 'SEM-3',
  section: 'A',
  academicYear: '2026-27',
  curriculumPlan: 'CBCS Regulation 2024 (Autonomous)',
  academicStanding: 'Distinction / Exemplary',
  academicClassification: 'First Class with Distinction',
  discountCategory: 'General Merit',
  intake: 'Single Window Counseling (TNEA)',
  programValidityDate: 'June 2029',
  dob: '09-09-2007',
  age: 18,
  gender: 'Female',
  fatherName: 'MR.SAKTHIVEL',
  motherName: 'Maheswari S',
  address: '1/80A, Nesavalar colony soolai veerappan chatram erode, Tamil Nadu, IN',
  city: 'Erode',
  state: 'Tamil Nadu',
  country: 'India',
  email: 'menmitha.25cb@excelcolleges.ac.in',
  phone: '+91 94432 87102',
  avatarUrl: '/src/assets/images/student_id_portrait_1791800408875.jpg',
  collegeLogoUrl: '/src/assets/images/college_emblem_logo_1791800422434.jpg',
  bloodGroup: 'O+ Positive',
  mentorName: 'Dr. K. Saravanan (Associate Professor, CSBS)',
  mentorCabin: 'Tech Tower III, Room 304, Autonomous Block'
};

export const academicRecords: SemesterRecord[] = [
  {
    semester: 'SEM-1',
    academicYear: '2025-26 (Odd)',
    sgpa: 8.68,
    creditsRegistered: 21,
    creditsEarned: 21,
    status: 'Completed',
    subjects: [
      { code: 'HS2511', name: 'Communicative English', credits: 3, type: 'Theory', faculty: 'Dr. A. Sudha', cia1: 44, cia2: 46, modelExam: 90, internalTotal: 47, predictedGrade: 'A+', status: 'Passed' },
      { code: 'MA2512', name: 'Engineering Mathematics I', credits: 4, type: 'Theory', faculty: 'Dr. R. Murugesan', cia1: 49, cia2: 50, modelExam: 98, internalTotal: 50, predictedGrade: 'O', status: 'Passed' },
      { code: 'PH2513', name: 'Engineering Physics', credits: 3, type: 'Theory', faculty: 'Prof. S. Vimal', cia1: 45, cia2: 44, modelExam: 89, internalTotal: 45, predictedGrade: 'A+', status: 'Passed' },
      { code: 'CY2514', name: 'Engineering Chemistry', credits: 3, type: 'Theory', faculty: 'Dr. M. Lakshmi', cia1: 42, cia2: 44, modelExam: 86, internalTotal: 43, predictedGrade: 'A', status: 'Passed' },
      { code: 'GE2515', name: 'Problem Solving & Python Programming', credits: 3, type: 'Theory', faculty: 'Prof. K. Saravanan', cia1: 50, cia2: 49, modelExam: 97, internalTotal: 50, predictedGrade: 'O', status: 'Passed' },
      { code: 'GE2521', name: 'Python Programming Laboratory', credits: 2, type: 'Practical', faculty: 'Prof. K. Saravanan', cia1: 48, cia2: 50, modelExam: 98, internalTotal: 49, predictedGrade: 'O', status: 'Passed' },
      { code: 'BS2522', name: 'Physics & Chemistry Laboratory', credits: 3, type: 'Practical', faculty: 'Prof. S. Vimal', cia1: 47, cia2: 48, modelExam: 94, internalTotal: 48, predictedGrade: 'O', status: 'Passed' }
    ]
  },
  {
    semester: 'SEM-2',
    academicYear: '2025-26 (Even)',
    sgpa: 8.84,
    creditsRegistered: 23,
    creditsEarned: 23,
    status: 'Completed',
    subjects: [
      { code: 'HS2521', name: 'Technical English & Report Writing', credits: 3, type: 'Theory', faculty: 'Dr. A. Sudha', cia1: 46, cia2: 47, modelExam: 92, internalTotal: 47, predictedGrade: 'A+', status: 'Passed' },
      { code: 'MA2522', name: 'Statistics & Numerical Methods', credits: 4, type: 'Theory', faculty: 'Dr. R. Murugesan', cia1: 48, cia2: 49, modelExam: 96, internalTotal: 49, predictedGrade: 'O', status: 'Passed' },
      { code: 'CB2523', name: 'Data Structures & Algorithms', credits: 4, type: 'Theory', faculty: 'Dr. P. Kavitha', cia1: 49, cia2: 50, modelExam: 98, internalTotal: 50, predictedGrade: 'O', status: 'Passed' },
      { code: 'CB2524', name: 'Digital Principles & System Architecture', credits: 3, type: 'Theory', faculty: 'Prof. G. Senthil', cia1: 45, cia2: 46, modelExam: 90, internalTotal: 46, predictedGrade: 'A+', status: 'Passed' },
      { code: 'CB2525', name: 'Object-Oriented Programming with C++', credits: 3, type: 'Theory', faculty: 'Prof. K. Saravanan', cia1: 48, cia2: 48, modelExam: 95, internalTotal: 48, predictedGrade: 'O', status: 'Passed' },
      { code: 'CB2531', name: 'Data Structures Laboratory', credits: 2, type: 'Practical', faculty: 'Dr. P. Kavitha', cia1: 50, cia2: 50, modelExam: 99, internalTotal: 50, predictedGrade: 'O', status: 'Passed' },
      { code: 'CB2532', name: 'OOP & C++ Practice Laboratory', credits: 2, type: 'Practical', faculty: 'Prof. K. Saravanan', cia1: 49, cia2: 50, modelExam: 98, internalTotal: 50, predictedGrade: 'O', status: 'Passed' },
      { code: 'GE2533', name: 'Design Thinking & Human Values', credits: 2, type: 'Theory', faculty: 'Dr. V. Arunkumar', cia1: 46, cia2: 47, modelExam: 93, internalTotal: 47, predictedGrade: 'A+', status: 'Passed' }
    ]
  },
  {
    semester: 'SEM-3',
    academicYear: '2026-27 (Current)',
    sgpa: 8.92,
    creditsRegistered: 24,
    creditsEarned: 24,
    status: 'Current',
    subjects: [
      { code: 'CB301', name: 'Discrete Mathematics & Combinatorics', credits: 4, type: 'Theory', faculty: 'Dr. R. Murugesan', cia1: 47, cia2: 48, modelExam: 94, internalTotal: 48, predictedGrade: 'O', status: 'In Progress' },
      { code: 'CB302', name: 'Design & Analysis of Algorithms', credits: 4, type: 'Theory', faculty: 'Prof. K. Saravanan', cia1: 49, cia2: 49, modelExam: 97, internalTotal: 49, predictedGrade: 'O', status: 'In Progress' },
      { code: 'CB303', name: 'Operating Systems & System Calls', credits: 3, type: 'Theory', faculty: 'Dr. M. Jayanthi', cia1: 44, cia2: 46, modelExam: 89, internalTotal: 45, predictedGrade: 'A+', status: 'In Progress' },
      { code: 'CB304', name: 'Fundamentals of Business Systems & Strategy', credits: 3, type: 'Theory', faculty: 'Prof. S. Ramesh', cia1: 48, cia2: 49, modelExam: 95, internalTotal: 49, predictedGrade: 'O', status: 'In Progress' },
      { code: 'CB305', name: 'Database Management Systems & NoSQL', credits: 3, type: 'Theory', faculty: 'Dr. P. Kavitha', cia1: 46, cia2: 48, modelExam: 93, internalTotal: 47, predictedGrade: 'A+', status: 'In Progress' },
      { code: 'CB306', name: 'Financial Accounting for Engineers', credits: 3, type: 'Theory', faculty: 'Prof. T. Selvam', cia1: 43, cia2: 45, modelExam: 88, internalTotal: 44, predictedGrade: 'A', status: 'In Progress' },
      { code: 'CB307', name: 'Algorithms & OS Laboratory', credits: 2, type: 'Practical', faculty: 'Prof. K. Saravanan', cia1: 50, cia2: 49, modelExam: 98, internalTotal: 50, predictedGrade: 'O', status: 'In Progress' },
      { code: 'CB308', name: 'DBMS & Query Tuning Laboratory', credits: 2, type: 'Practical', faculty: 'Dr. P. Kavitha', cia1: 49, cia2: 50, modelExam: 99, internalTotal: 50, predictedGrade: 'O', status: 'In Progress' }
    ]
  }
];

export const attendanceData: AttendanceRecord = {
  overallPercentage: 91.8,
  totalConducted: 390,
  totalAttended: 350,
  totalOd: 8,
  minimumRequired: 75.0,
  subjectWise: [
    {
      code: 'CB301',
      name: 'Discrete Mathematics & Combinatorics',
      faculty: 'Dr. R. Murugesan',
      conducted: 52,
      attended: 48,
      odApproved: 1,
      percentage: 94.2,
      requiredClassesTo75: 0,
      canBunkClasses: 13,
      status: 'Safe'
    },
    {
      code: 'CB302',
      name: 'Design & Analysis of Algorithms',
      faculty: 'Prof. K. Saravanan',
      conducted: 54,
      attended: 51,
      odApproved: 2,
      percentage: 98.1,
      requiredClassesTo75: 0,
      canBunkClasses: 16,
      status: 'Safe'
    },
    {
      code: 'CB303',
      name: 'Operating Systems & System Calls',
      faculty: 'Dr. M. Jayanthi',
      conducted: 48,
      attended: 42,
      odApproved: 1,
      percentage: 89.5,
      requiredClassesTo75: 0,
      canBunkClasses: 9,
      status: 'Safe'
    },
    {
      code: 'CB304',
      name: 'Fundamentals of Business Systems',
      faculty: 'Prof. S. Ramesh',
      conducted: 46,
      attended: 41,
      odApproved: 2,
      percentage: 93.4,
      requiredClassesTo75: 0,
      canBunkClasses: 11,
      status: 'Safe'
    },
    {
      code: 'CB305',
      name: 'Database Management Systems',
      faculty: 'Dr. P. Kavitha',
      conducted: 50,
      attended: 45,
      odApproved: 1,
      percentage: 92.0,
      requiredClassesTo75: 0,
      canBunkClasses: 11,
      status: 'Safe'
    },
    {
      code: 'CB306',
      name: 'Financial Accounting for Engineers',
      faculty: 'Prof. T. Selvam',
      conducted: 44,
      attended: 37,
      odApproved: 1,
      percentage: 86.3,
      requiredClassesTo75: 0,
      canBunkClasses: 6,
      status: 'Safe'
    },
    {
      code: 'CB307',
      name: 'Algorithms & OS Laboratory',
      faculty: 'Prof. K. Saravanan',
      conducted: 48,
      attended: 46,
      odApproved: 0,
      percentage: 95.8,
      requiredClassesTo75: 0,
      canBunkClasses: 13,
      status: 'Safe'
    },
    {
      code: 'CB308',
      name: 'DBMS & Query Tuning Laboratory',
      faculty: 'Dr. P. Kavitha',
      conducted: 48,
      attended: 40,
      odApproved: 0,
      percentage: 83.3,
      requiredClassesTo75: 0,
      canBunkClasses: 5,
      status: 'Safe'
    }
  ],
  recentLogs: [
    {
      date: '2026-10-10',
      day: 'Saturday (Compensatory)',
      periods: [
        { period: 1, subject: 'CB301 (Maths)', status: 'Present' },
        { period: 2, subject: 'CB302 (DAA)', status: 'Present' },
        { period: 3, subject: 'CB303 (OS)', status: 'Present' },
        { period: 4, subject: 'CB304 (Business)', status: 'Present' },
        { period: 5, subject: 'CB307 (Lab)', status: 'Present' },
        { period: 6, subject: 'CB307 (Lab)', status: 'Present' }
      ]
    },
    {
      date: '2026-10-09',
      day: 'Friday',
      periods: [
        { period: 1, subject: 'CB305 (DBMS)', status: 'Present' },
        { period: 2, subject: 'CB306 (Accounting)', status: 'Absent' },
        { period: 3, subject: 'CB302 (DAA)', status: 'Present' },
        { period: 4, subject: 'CB301 (Maths)', status: 'Present' },
        { period: 5, subject: 'CB308 (DBMS Lab)', status: 'Present' },
        { period: 6, subject: 'CB308 (DBMS Lab)', status: 'Present' }
      ]
    },
    {
      date: '2026-10-08',
      day: 'Thursday',
      periods: [
        { period: 1, subject: 'CB304 (Business)', status: 'Present' },
        { period: 2, subject: 'CB303 (OS)', status: 'OD' },
        { period: 3, subject: 'CB301 (Maths)', status: 'OD' },
        { period: 4, subject: 'CB305 (DBMS)', status: 'Present' },
        { period: 5, subject: 'Library / Placement Hour', status: 'Present' },
        { period: 6, subject: 'Mentoring / Proctor Hour', status: 'Present' }
      ]
    }
  ]
};

export const lmsCourses: LMSCourse[] = [
  { code: 'CB302', name: 'Design & Analysis of Algorithms', faculty: 'Prof. K. Saravanan', progressPercentage: 88, materialsCount: 26, assignmentsPending: 1, lastAccessed: 'Today, 09:40 AM' },
  { code: 'CB305', name: 'Database Management Systems & NoSQL', faculty: 'Dr. P. Kavitha', progressPercentage: 82, materialsCount: 31, assignmentsPending: 0, lastAccessed: 'Yesterday, 04:15 PM' },
  { code: 'CB301', name: 'Discrete Mathematics & Combinatorics', faculty: 'Dr. R. Murugesan', progressPercentage: 90, materialsCount: 18, assignmentsPending: 1, lastAccessed: '2 days ago' },
  { code: 'CB304', name: 'Fundamentals of Business Systems', faculty: 'Prof. S. Ramesh', progressPercentage: 76, materialsCount: 22, assignmentsPending: 0, lastAccessed: '3 days ago' },
  { code: 'CB303', name: 'Operating Systems & System Calls', faculty: 'Dr. M. Jayanthi', progressPercentage: 70, materialsCount: 24, assignmentsPending: 1, lastAccessed: 'Yesterday, 11:20 AM' },
  { code: 'CB306', name: 'Financial Accounting for Engineers', faculty: 'Prof. T. Selvam', progressPercentage: 65, materialsCount: 15, assignmentsPending: 0, lastAccessed: '4 days ago' }
];

export const assignmentsList: Assignment[] = [
  {
    id: 'asg-302-2',
    courseCode: 'CB302',
    courseName: 'Design & Analysis of Algorithms',
    title: 'Assignment 3: Dynamic Programming vs Greedy Strategy in Knapsack Variants',
    dueDate: '2026-10-18',
    points: 20,
    status: 'Pending'
  },
  {
    id: 'asg-301-4',
    courseCode: 'CB301',
    courseName: 'Discrete Mathematics',
    title: 'Problem Set 4: Planar Graphs, Euler Formula & Chromatic Polynomials',
    dueDate: '2026-10-22',
    points: 20,
    status: 'Pending'
  },
  {
    id: 'asg-303-3',
    courseCode: 'CB303',
    courseName: 'Operating Systems',
    title: 'Shell Scripting & POSIX Thread Synchronization in C',
    dueDate: '2026-10-25',
    points: 25,
    status: 'Pending'
  },
  {
    id: 'asg-305-2',
    courseCode: 'CB305',
    courseName: 'Database Management Systems',
    title: 'Schema Normalization (3NF & BCNF) with Real-Time ERP Case Study',
    dueDate: '2026-10-05',
    points: 20,
    status: 'Evaluated',
    score: 19.5,
    feedback: 'Excellent breakdown of functional dependencies and normalization diagrams.',
    submissionDate: '2026-10-04'
  },
  {
    id: 'asg-304-1',
    courseCode: 'CB304',
    courseName: 'Fundamentals of Business Systems',
    title: 'Enterprise Process Mapping for Supply Chain Logistics',
    dueDate: '2026-09-28',
    points: 20,
    status: 'Evaluated',
    score: 19.0,
    feedback: 'Well articulated BPMN diagrams and cost optimization metrics.',
    submissionDate: '2026-09-27'
  }
];

export const placementMetrics: PlacementMetric = {
  aptitudeScore: 86,
  codingScore: 88,
  verbalScore: 84,
  mockInterviewScore: 4.6,
  readinessRating: 'High',
  codingProfiles: [
    { platform: 'LeetCode', rating: '1680 (Knight contender)', solved: 242 },
    { platform: 'SkillRack / Internal Portal', rating: 'Gold Medal (Rank 4 in Dept)', solved: 512 },
    { platform: 'HackerRank', rating: '5 Stars (C++, Python, SQL)', solved: 130 }
  ],
  targetCompanies: [
    { company: 'Zoho Corporation', role: 'Software Development Engineer', packageLpa: '8.4 - 12.0 LPA', criteriaMet: true, tier: 'Dream' },
    { company: 'TCS Digital', role: 'System Engineer Specialist', packageLpa: '7.5 - 9.0 LPA', criteriaMet: true, tier: 'Dream' },
    { company: 'Cognizant (GenC Next)', role: 'Full Stack Engineer', packageLpa: '6.75 LPA', criteriaMet: true, tier: 'Core' },
    { company: 'Thoughtworks', role: 'Graduate Consultant Developer', packageLpa: '11.5 LPA', criteriaMet: true, tier: 'Super Dream' },
    { company: 'Infosys (Specialist Programmer)', role: 'SP / DSE', packageLpa: '9.5 LPA', criteriaMet: true, tier: 'Dream' }
  ],
  interviewRemarks: [
    {
      interviewer: 'Placement Advisory Panel (Mr. D. Praveen & External Industry Mentor)',
      date: '2026-09-20',
      verdict: 'Recommended for Tier-1 Product Track',
      notes: 'Strong conceptual grasp of algorithmic time complexities, clean OOP code structure in C++, fluent technical communication.'
    },
    {
      interviewer: 'Department Technical Committee (Dr. P. Kavitha)',
      date: '2026-08-15',
      verdict: 'Cleared Phase 1 Benchmark',
      notes: 'Demonstrated solid understanding of SQL joins, normalization, and relational calculus.'
    }
  ]
};

export const skillsInventory: SkillItem[] = [
  { name: 'Data Structures & Algorithms', category: 'Technical', proficiency: 90, verifiedBy: 'Dept Benchmark 2026' },
  { name: 'C++ & Object-Oriented Design', category: 'Technical', proficiency: 88, verifiedBy: 'Internal Assessment' },
  { name: 'Python & Data Analysis', category: 'Technical', proficiency: 92, verifiedBy: 'NPTEL Elite Exam' },
  { name: 'SQL & Database Architecture', category: 'Technical', proficiency: 85, verifiedBy: 'Coursera Verification' },
  { name: 'Linux OS & Shell Scripting', category: 'Technical', proficiency: 78, verifiedBy: 'Faculty Review' },
  { name: 'Business Process Analysis', category: 'Domain', proficiency: 86, verifiedBy: 'Course CIA 1' },
  { name: 'Technical Presentation & Speech', category: 'Soft Skills', proficiency: 88, verifiedBy: 'Rotaract & GDSC' },
  { name: 'Team Leadership & Collaboration', category: 'Soft Skills', proficiency: 90, verifiedBy: 'Smart India Hackathon' }
];

export const certificationsList: Certification[] = [
  { id: 'cert-1', title: 'Joy of Computing using Python', issuer: 'NPTEL / IIT Madras', issueDate: 'May 2026', credentialId: 'NPTEL26CS45S198', badgeType: 'Elite', category: 'Programming' },
  { id: 'cert-2', title: 'Database Structures and Management with MySQL', issuer: 'Meta / Coursera', issueDate: 'August 2026', credentialId: 'META-DB-881294', badgeType: 'Gold', category: 'Data' },
  { id: 'cert-3', title: 'AWS Cloud Practitioner Essentials', issuer: 'Amazon Web Services', issueDate: 'September 2026', credentialId: 'AWS-TR-2026-4412', badgeType: 'Standard', category: 'Cloud' },
  { id: 'cert-4', title: 'Enterprise Business Fundamentals', issuer: 'Infosys Springboard', issueDate: 'July 2026', credentialId: 'INF-SP-9921', badgeType: 'Gold', category: 'Management' }
];

// Student Segmentation Models (as highlighted in camu2.jpeg bonus feature)
export const studentSegments: StudentSegment[] = [
  {
    id: 'seg-high-acad-high-place',
    name: 'Exemplar (High Academics · High Placement)',
    criteria: 'CGPA ≥ 8.5 & Coding/Aptitude ≥ 80%',
    description: 'Students excelling uniformly across university examinations and competitive placement benchmarks.',
    colorTheme: 'emerald',
    studentCountInCollege: 34,
    interventionPlan: [
      'Fast-track to Super Dream company interviews (12+ LPA)',
      'Nominate for Tier-1 external hackathons and national paper presentations',
      'Assign peer mentorship responsibilities to assist struggling classmates'
    ],
    recommendedAction: 'Super Dream Company Exclusive Mentorship Track',
    currentStudentBelongs: true // Menmitha S belongs here!
  },
  {
    id: 'seg-high-acad-low-place',
    name: 'Bridge Cohort (High Academics · Low Placement Readiness)',
    criteria: 'CGPA ≥ 8.0 & Placement Readiness < 65%',
    description: 'Strong theoretical grasp and semester marks, but hesitant in live competitive coding, speed aptitude, or technical GDs.',
    colorTheme: 'blue',
    studentCountInCollege: 58,
    interventionPlan: [
      'Mandatory daily 1-hour timed aptitude sprint on campus portal',
      'Pair coding sessions with high-ranking peer coders',
      'Mock interview clinic focusing on spontaneous technical problem solving'
    ],
    recommendedAction: 'Targeted Coding Sprints & Mock Interview Clinics',
    currentStudentBelongs: false
  },
  {
    id: 'seg-low-acad-high-place',
    name: 'Practitioners (Moderate Academics · High Placement Skills)',
    criteria: 'CGPA < 7.5 & Coding/Aptitude ≥ 80%',
    description: 'Exceptional hands-on developers and competitive coders whose semester theory grades or internal marks lag.',
    colorTheme: 'amber',
    studentCountInCollege: 28,
    interventionPlan: [
      'Targeted university exam answer script structuring tutorials',
      'Remedial coaching for core theory papers to eliminate arrear risks',
      'Ensure 0 active backlogs so student meets 60% / 7.0 CGPA corporate cutoffs'
    ],
    recommendedAction: 'Theory Exam Remedial & Backlog Prevention Support',
    currentStudentBelongs: false
  },
  {
    id: 'seg-attendance-risk',
    name: 'Attendance Watchlist (Attendance < 78%)',
    criteria: 'Overall Attendance < 78% (Autonomous cutoff is 75%)',
    description: 'Students approaching autonomous hall ticket withholding zone due to leaves, medical gaps, or unapproved absences.',
    colorTheme: 'rose',
    studentCountInCollege: 22,
    interventionPlan: [
      'Proctor tele-counseling with parent/guardian acknowledgment',
      'Daily biometric tracking alert triggered at 09:15 AM',
      'Compensatory academic hours and On-Duty (OD) regularization review'
    ],
    recommendedAction: 'Parent-Proctor Advisory & Compensatory Hour Allocation',
    currentStudentBelongs: false
  }
];

export const engagementActivities = [
  { title: 'Google Developer Student Clubs (GDSC)', role: 'Core Technical Member', tenure: '2025 - Present', category: 'Technical Club' },
  { title: 'Smart India Hackathon (SIH 2026)', role: 'Team Lead - AI driven Agritech Logistics', tenure: 'College Round Winner', category: 'Hackathon' },
  { title: 'Computer Society of India (CSI)', role: 'Student Member', tenure: 'Active', category: 'Professional Society' },
  { title: 'National Coding Conclave, Coimbatore', role: 'Runner-up (Team of 3)', tenure: 'August 2026', category: 'Competition' }
];

export const mentorNotes = [
  {
    date: '02 Oct 2026',
    faculty: 'Dr. K. Saravanan (Associate Professor & Class Advisor)',
    category: 'Academic & Placement Review',
    content: 'Menmitha maintains exceptional focus across all Continuous Internal Assessments. Her attendance at 91.8% is exemplary. Advised her to attempt the upcoming TCS CodeVita Season 14 and lead the department team in Smart India Hackathon finals.'
  },
  {
    date: '14 Aug 2026',
    faculty: 'Dr. P. Kavitha (HOD & Professor, CSBS)',
    category: 'Department Commendation',
    content: 'Awarded Semester Academic Merit Certificate for securing 8.84 SGPA in SEM-2 with zero arrears. Encouraged to take on NPTEL Elite certifications in Advanced Data Analytics.'
  }
];
