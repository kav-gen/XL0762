export interface SectionComparisonMetric {
  sectionId: 'A' | 'B' | 'C' | 'D';
  sectionName: string;
  totalStudents: number;
  classAdvisor: string;
  roomNumber: string;
  attendancePercentage: number;
  passPercentage: number;
  avgCgpa: number;
  placementReadiness: number;
  internalAssessmentAvg: number;
  atRiskCount: number;
  topStudent: string;
  gradeDistribution: {
    O: number;
    A_plus: number;
    A: number;
    B_plus: number;
    B: number;
    Arrear: number;
  };
}

export interface FacultyWorkloadRecord {
  id: string;
  name: string;
  designation: 'Professor' | 'Associate Professor' | 'Assistant Professor (Sr)' | 'Assistant Professor';
  qualification: string;
  experienceYears: number;
  theoryHours: number;
  labHours: number;
  mentoringAndAdminHours: number;
  totalHours: number; // AICTE standard norm: 16-20 hrs/week
  workloadStatus: 'OPTIMAL' | 'FULL LOAD' | 'OVERLOAD' | 'UNDERLOAD';
  assignedSubjects: string[];
  assignedMenteesCount: number;
  publicationsThisYear: number;
  specialization: string;
  photoUrl: string;
}

export const departmentStats = {
  departmentName: 'Computer Science and Business Systems (CSBS)',
  college: 'Excel Engineering College (Autonomous)',
  hodName: 'Dr. S. Rajendran, M.Tech., Ph.D.',
  hodCabin: 'Academic Block A, HOD Suite 101',
  totalStudents: 500, // Total department enrolled
  batchDistribution: {
    firstYear: 130,
    secondYear: 125,
    thirdYear: 125,
    finalYear: 120
  },
  overallPassPercentage: 92.4,
  lastSemesterPassPercentage: 89.2,
  passPercentageDelta: '+3.2%',
  departmentAvgCgpa: 7.92,
  departmentAvgAttendance: 86.8,
  placementStats: {
    eligibleStudents: 300,
    placedStudents: 235,
    placementPercentage: 78.5,
    highestCtc: '18.5 LPA',
    averageCtc: '5.8 LPA',
    tier1Offers: 84,
    dreamOffers: 42,
    topRecruiters: ['TCS Digital', 'Zoho Corp', 'Cognizant GenC Elevate', 'Virtusa', 'Accenture', 'Bosch']
  },
  facultySummary: {
    totalFaculty: 24,
    professors: 4,
    assocProfessors: 7,
    asstProfessors: 13,
    doctoratesCount: 15,
    pursuingDoctorates: 7,
    studentFacultyRatio: '20.8 : 1 (AICTE Compliant)'
  },
  researchMetrics: {
    papersPublishedScopus: 42,
    activeFundedGrants: '₹42.50 Lakhs (DST & AICTE RPS)',
    patentsFiled: 11,
    patentsGranted: 3,
    activeMous: 8
  }
};

export const sectionsComparisonData: SectionComparisonMetric[] = [
  {
    sectionId: 'A',
    sectionName: 'CSBS - Section A',
    totalStudents: 128,
    classAdvisor: 'Dr. K. Vigneshwaran (Assoc. Prof)',
    roomNumber: 'AB-201',
    attendancePercentage: 89.4,
    passPercentage: 94.5,
    avgCgpa: 8.12,
    placementReadiness: 83.2,
    internalAssessmentAvg: 82.5,
    atRiskCount: 8,
    topStudent: 'MENMITHA S (8.78 CGPA)',
    gradeDistribution: {
      O: 24,
      A_plus: 42,
      A: 38,
      B_plus: 16,
      B: 6,
      Arrear: 2
    }
  },
  {
    sectionId: 'B',
    sectionName: 'CSBS - Section B',
    totalStudents: 124,
    classAdvisor: 'Dr. M. Saravanan (Professor)',
    roomNumber: 'AB-202',
    attendancePercentage: 86.2,
    passPercentage: 91.8,
    avgCgpa: 7.88,
    placementReadiness: 77.5,
    internalAssessmentAvg: 78.0,
    atRiskCount: 14,
    topStudent: 'Dharun Kumar K (8.65 CGPA)',
    gradeDistribution: {
      O: 18,
      A_plus: 36,
      A: 44,
      B_plus: 18,
      B: 5,
      Arrear: 3
    }
  },
  {
    sectionId: 'C',
    sectionName: 'CSBS - Section C',
    totalStudents: 126,
    classAdvisor: 'Dr. P. Kavitha (Assoc. Prof)',
    roomNumber: 'AB-203',
    attendancePercentage: 87.5,
    passPercentage: 93.2,
    avgCgpa: 7.96,
    placementReadiness: 79.4,
    internalAssessmentAvg: 80.2,
    atRiskCount: 11,
    topStudent: 'Ananya S (8.72 CGPA)',
    gradeDistribution: {
      O: 21,
      A_plus: 39,
      A: 41,
      B_plus: 17,
      B: 6,
      Arrear: 2
    }
  },
  {
    sectionId: 'D',
    sectionName: 'CSBS - Section D',
    totalStudents: 122,
    classAdvisor: 'Dr. R. Karthik (Asst. Prof Sr.)',
    roomNumber: 'AB-204',
    attendancePercentage: 84.1,
    passPercentage: 89.9,
    avgCgpa: 7.74,
    placementReadiness: 74.0,
    internalAssessmentAvg: 75.8,
    atRiskCount: 17,
    topStudent: 'Vigneshwaran P (8.54 CGPA)',
    gradeDistribution: {
      O: 15,
      A_plus: 32,
      A: 45,
      B_plus: 20,
      B: 7,
      Arrear: 3
    }
  }
];

export const monthlyTrendsData = {
  months: ['Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar'],
  attendanceBySection: {
    secA: [92.0, 91.2, 89.8, 88.5, 93.0, 90.4, 89.1, 89.4],
    secB: [88.5, 87.4, 86.0, 85.2, 89.5, 86.8, 85.9, 86.2],
    secC: [90.0, 88.8, 87.5, 86.9, 91.2, 88.0, 87.2, 87.5],
    secD: [86.5, 85.0, 83.8, 82.5, 87.0, 84.6, 83.9, 84.1]
  },
  ciaExamAverages: {
    secA: [78.2, 81.5, 82.5],
    secB: [74.5, 76.8, 78.0],
    secC: [76.0, 78.4, 80.2],
    secD: [72.8, 74.5, 75.8]
  }
};

// 24 Full-Time Faculty Members with AICTE Workload Norms
export const facultyWorkloadData: FacultyWorkloadRecord[] = [
  {
    id: 'fac-01',
    name: 'Dr. S. Rajendran',
    designation: 'Professor',
    qualification: 'M.Tech., Ph.D.',
    experienceYears: 21,
    theoryHours: 8,
    labHours: 2,
    mentoringAndAdminHours: 8,
    totalHours: 18,
    workloadStatus: 'OPTIMAL',
    assignedSubjects: ['Business Strategy & Tech Policy (CB701)'],
    assignedMenteesCount: 20,
    publicationsThisYear: 5,
    specialization: 'Distributed Systems & Tech Management',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'fac-02',
    name: 'Dr. M. Saravanan',
    designation: 'Professor',
    qualification: 'M.E., Ph.D.',
    experienceYears: 18,
    theoryHours: 10,
    labHours: 4,
    mentoringAndAdminHours: 4,
    totalHours: 18,
    workloadStatus: 'OPTIMAL',
    assignedSubjects: ['Design and Analysis of Algorithms (CB302)', 'DAA Lab (CB312)'],
    assignedMenteesCount: 25,
    publicationsThisYear: 4,
    specialization: 'Algorithms & Theoretical Computer Science',
    photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'fac-03',
    name: 'Dr. K. Vigneshwaran',
    designation: 'Associate Professor',
    qualification: 'M.E., Ph.D.',
    experienceYears: 14,
    theoryHours: 11,
    labHours: 4,
    mentoringAndAdminHours: 4,
    totalHours: 19,
    workloadStatus: 'FULL LOAD',
    assignedSubjects: ['Discrete Mathematics (CB301)', 'Operating Systems (CB303)', 'OS Lab (CB313)'],
    assignedMenteesCount: 60, // Class Advisor for 60 students
    publicationsThisYear: 3,
    specialization: 'Discrete Structures & Cloud Operating Systems',
    photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'fac-04',
    name: 'Dr. P. Kavitha',
    designation: 'Associate Professor',
    qualification: 'M.Tech., Ph.D.',
    experienceYears: 13,
    theoryHours: 10,
    labHours: 6,
    mentoringAndAdminHours: 2,
    totalHours: 18,
    workloadStatus: 'OPTIMAL',
    assignedSubjects: ['Database Management Systems (CB305)', 'DBMS Lab (CB315)'],
    assignedMenteesCount: 25,
    publicationsThisYear: 3,
    specialization: 'Distributed DBMS & Big Data Analytics',
    photoUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'fac-05',
    name: 'Dr. R. Karthik',
    designation: 'Assistant Professor (Sr)',
    qualification: 'M.E., Ph.D.',
    experienceYears: 9,
    theoryHours: 12,
    labHours: 6,
    mentoringAndAdminHours: 2,
    totalHours: 20,
    workloadStatus: 'FULL LOAD',
    assignedSubjects: ['Software Engineering & Agile (CB304)', 'SE Case Tools Lab (CB314)'],
    assignedMenteesCount: 22,
    publicationsThisYear: 2,
    specialization: 'Agile Software Architectures & DevOps',
    photoUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'fac-06',
    name: 'Dr. A. Meenakshi',
    designation: 'Associate Professor',
    qualification: 'M.E., Ph.D.',
    experienceYears: 12,
    theoryHours: 10,
    labHours: 6,
    mentoringAndAdminHours: 2,
    totalHours: 18,
    workloadStatus: 'OPTIMAL',
    assignedSubjects: ['Machine Learning for Business (CB502)', 'ML Laboratory (CB512)'],
    assignedMenteesCount: 20,
    publicationsThisYear: 3,
    specialization: 'Deep Learning & Natural Language Processing',
    photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'fac-07',
    name: 'Dr. S. Prakash',
    designation: 'Professor',
    qualification: 'M.E., Ph.D.',
    experienceYears: 19,
    theoryHours: 9,
    labHours: 4,
    mentoringAndAdminHours: 4,
    totalHours: 17,
    workloadStatus: 'OPTIMAL',
    assignedSubjects: ['Computer Networks & IoT (CB401)', 'Networks Lab (CB411)'],
    assignedMenteesCount: 22,
    publicationsThisYear: 4,
    specialization: 'Wireless Sensor Networks & Cyber Security',
    photoUrl: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'fac-08',
    name: 'Dr. V. Deepa',
    designation: 'Associate Professor',
    qualification: 'M.Tech., Ph.D.',
    experienceYears: 11,
    theoryHours: 10,
    labHours: 4,
    mentoringAndAdminHours: 3,
    totalHours: 17,
    workloadStatus: 'OPTIMAL',
    assignedSubjects: ['Financial Accounting & Valuation (CB306)'],
    assignedMenteesCount: 20,
    publicationsThisYear: 2,
    specialization: 'FinTech & Computational Economics',
    photoUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'fac-09',
    name: 'Prof. T. Selvakumar',
    designation: 'Assistant Professor (Sr)',
    qualification: 'M.E. (Ph.D.)',
    experienceYears: 8,
    theoryHours: 12,
    labHours: 8,
    mentoringAndAdminHours: 2,
    totalHours: 22,
    workloadStatus: 'OVERLOAD',
    assignedSubjects: ['Object Oriented Programming Java (CB201)', 'Java Lab (CB211)', 'Python Lab'],
    assignedMenteesCount: 24,
    publicationsThisYear: 1,
    specialization: 'Full Stack Web & Microservices',
    photoUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'fac-10',
    name: 'Prof. G. Anitha',
    designation: 'Assistant Professor (Sr)',
    qualification: 'M.E. (Ph.D.)',
    experienceYears: 7,
    theoryHours: 12,
    labHours: 6,
    mentoringAndAdminHours: 1,
    totalHours: 19,
    workloadStatus: 'FULL LOAD',
    assignedSubjects: ['Artificial Intelligence Principles (CB501)', 'AI Lab (CB511)'],
    assignedMenteesCount: 20,
    publicationsThisYear: 1,
    specialization: 'Knowledge Graphs & Expert Systems',
    photoUrl: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'fac-11',
    name: 'Dr. C. Manikandan',
    designation: 'Associate Professor',
    qualification: 'M.E., Ph.D.',
    experienceYears: 14,
    theoryHours: 9,
    labHours: 6,
    mentoringAndAdminHours: 3,
    totalHours: 18,
    workloadStatus: 'OPTIMAL',
    assignedSubjects: ['Cloud Computing & Virtualization (CB601)', 'Cloud DevOps Lab'],
    assignedMenteesCount: 20,
    publicationsThisYear: 2,
    specialization: 'Container Orchestration & Cloud Security',
    photoUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'fac-12',
    name: 'Prof. N. Revathi',
    designation: 'Assistant Professor',
    qualification: 'M.Tech.',
    experienceYears: 5,
    theoryHours: 12,
    labHours: 6,
    mentoringAndAdminHours: 1,
    totalHours: 19,
    workloadStatus: 'FULL LOAD',
    assignedSubjects: ['Data Warehousing & Mining (CB603)', 'BI Analytics Lab'],
    assignedMenteesCount: 18,
    publicationsThisYear: 1,
    specialization: 'Data Engineering & Predictive Analytics',
    photoUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'fac-13',
    name: 'Dr. B. Loganathan',
    designation: 'Associate Professor',
    qualification: 'M.E., Ph.D.',
    experienceYears: 15,
    theoryHours: 8,
    labHours: 4,
    mentoringAndAdminHours: 4,
    totalHours: 16,
    workloadStatus: 'OPTIMAL',
    assignedSubjects: ['Cyber Forensics & Incident Response (CB703)'],
    assignedMenteesCount: 22,
    publicationsThisYear: 3,
    specialization: 'Information Security & Cryptography',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'fac-14',
    name: 'Prof. S. Divya',
    designation: 'Assistant Professor',
    qualification: 'M.E.',
    experienceYears: 4,
    theoryHours: 10,
    labHours: 4,
    mentoringAndAdminHours: 1,
    totalHours: 15,
    workloadStatus: 'UNDERLOAD',
    assignedSubjects: ['Web Technology & Frameworks (CB404)', 'Web Lab (CB414)'],
    assignedMenteesCount: 18,
    publicationsThisYear: 0,
    specialization: 'Frontend Frameworks & UX Design',
    photoUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'fac-15',
    name: 'Prof. R. Suresh',
    designation: 'Assistant Professor',
    qualification: 'M.Tech.',
    experienceYears: 6,
    theoryHours: 12,
    labHours: 6,
    mentoringAndAdminHours: 1,
    totalHours: 19,
    workloadStatus: 'FULL LOAD',
    assignedSubjects: ['Computer Organization & Architecture (CB203)', 'Hardware Lab'],
    assignedMenteesCount: 20,
    publicationsThisYear: 1,
    specialization: 'Computer Architecture & VLSI Basics',
    photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'fac-16',
    name: 'Dr. K. Jayanthi',
    designation: 'Professor',
    qualification: 'M.E., Ph.D.',
    experienceYears: 20,
    theoryHours: 8,
    labHours: 4,
    mentoringAndAdminHours: 5,
    totalHours: 17,
    workloadStatus: 'OPTIMAL',
    assignedSubjects: ['Operations Research & Optimization (CB504)'],
    assignedMenteesCount: 22,
    publicationsThisYear: 4,
    specialization: 'Linear Programming & Stochastic Models',
    photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'fac-17',
    name: 'Prof. M. Vijayalakshmi',
    designation: 'Assistant Professor (Sr)',
    qualification: 'M.E. (Ph.D.)',
    experienceYears: 8,
    theoryHours: 12,
    labHours: 6,
    mentoringAndAdminHours: 1,
    totalHours: 19,
    workloadStatus: 'FULL LOAD',
    assignedSubjects: ['Compiler Design (CB503)', 'Compiler Lab (CB513)'],
    assignedMenteesCount: 20,
    publicationsThisYear: 1,
    specialization: 'Code Optimization & Automata Theory',
    photoUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'fac-18',
    name: 'Prof. P. Naveen',
    designation: 'Assistant Professor',
    qualification: 'M.E.',
    experienceYears: 4,
    theoryHours: 12,
    labHours: 8,
    mentoringAndAdminHours: 1,
    totalHours: 21,
    workloadStatus: 'OVERLOAD',
    assignedSubjects: ['Mobile Application Development (CB604)', 'Mobile Lab', 'IoT Workshop'],
    assignedMenteesCount: 20,
    publicationsThisYear: 0,
    specialization: 'Flutter & Android Architecture',
    photoUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'fac-19',
    name: 'Dr. T. Shanmugam',
    designation: 'Associate Professor',
    qualification: 'M.E., Ph.D.',
    experienceYears: 13,
    theoryHours: 9,
    labHours: 6,
    mentoringAndAdminHours: 2,
    totalHours: 17,
    workloadStatus: 'OPTIMAL',
    assignedSubjects: ['Natural Language Processing (CB702)', 'NLP Lab'],
    assignedMenteesCount: 20,
    publicationsThisYear: 3,
    specialization: 'Transformer Architectures & Speech AI',
    photoUrl: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'fac-20',
    name: 'Prof. S. Preethi',
    designation: 'Assistant Professor',
    qualification: 'M.Tech.',
    experienceYears: 5,
    theoryHours: 12,
    labHours: 4,
    mentoringAndAdminHours: 1,
    totalHours: 17,
    workloadStatus: 'OPTIMAL',
    assignedSubjects: ['Human Computer Interaction (CB405)', 'Design Thinking Lab'],
    assignedMenteesCount: 18,
    publicationsThisYear: 1,
    specialization: 'Interaction Design & Ergonomics',
    photoUrl: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'fac-21',
    name: 'Prof. D. Karthikeyan',
    designation: 'Assistant Professor',
    qualification: 'M.E.',
    experienceYears: 5,
    theoryHours: 10,
    labHours: 4,
    mentoringAndAdminHours: 1,
    totalHours: 15,
    workloadStatus: 'UNDERLOAD',
    assignedSubjects: ['Business Communication & Ethics (CB104)'],
    assignedMenteesCount: 18,
    publicationsThisYear: 0,
    specialization: 'Corporate Governance & Professional Ethics',
    photoUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'fac-22',
    name: 'Dr. E. Saradha',
    designation: 'Associate Professor',
    qualification: 'M.Tech., Ph.D.',
    experienceYears: 12,
    theoryHours: 10,
    labHours: 4,
    mentoringAndAdminHours: 3,
    totalHours: 17,
    workloadStatus: 'OPTIMAL',
    assignedSubjects: ['Predictive Modeling (CB602)', 'R-Programming Lab'],
    assignedMenteesCount: 22,
    publicationsThisYear: 2,
    specialization: 'Biostatistics & Econometrics',
    photoUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'fac-23',
    name: 'Prof. J. Antony Raj',
    designation: 'Assistant Professor (Sr)',
    qualification: 'M.E. (Ph.D.)',
    experienceYears: 7,
    theoryHours: 12,
    labHours: 6,
    mentoringAndAdminHours: 1,
    totalHours: 19,
    workloadStatus: 'FULL LOAD',
    assignedSubjects: ['Blockchain Technologies (CB704)', 'Smart Contracts Lab'],
    assignedMenteesCount: 20,
    publicationsThisYear: 2,
    specialization: 'Ethereum & Decentralized Systems',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'
  },
  {
    id: 'fac-24',
    name: 'Prof. M. Balamurugan',
    designation: 'Assistant Professor',
    qualification: 'M.E.',
    experienceYears: 6,
    theoryHours: 11,
    labHours: 6,
    mentoringAndAdminHours: 1,
    totalHours: 18,
    workloadStatus: 'OPTIMAL',
    assignedSubjects: ['Introduction to Innovation & IP (CB204)', 'Design Studio Lab'],
    assignedMenteesCount: 20,
    publicationsThisYear: 1,
    specialization: 'Patent Law & Product Prototyping',
    photoUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80'
  }
];
